package test_suites;

import java.io.IOException;

import org.apache.commons.lang3.tuple.Pair;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import manager_objects.ExtentManager;

public class SurveysPageTest extends BaseTest {

	Pair<Boolean, String> validation_status;
	String operating_room_count, procedure_room_count, patient_admission_count = "";
	// Please fill with valid search entries
	String facility_id = "";
	String facility_name = "";
	String survey_year = "";
	String survey_type = "";

	@BeforeMethod
	public void login() throws IOException, InterruptedException {
		loginPage.inputUserNameAndPassword();
		loginPage.login();
	}

	@Test
	public void validateAddSurveysPage() throws InterruptedException, IOException {
		landingPage.selectComponent();
		landingPage.selectFacility();
		landingPage.submitSelection();
		surveysPage.selectMenu(surveysPage.page_name);
		// Test case 1
		validation_status = surveysPage.verifyPageWithSoftAssertion(surveysPage.page_name);
		ExtentManager.ExecuteTest("Verify Surveys Page", validation_status.getLeft(), validation_status.getRight(), driver, "Surveys page");

		surveysPage.clickAdd();
		// Test case 2
		validation_status = surveysPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Add Surveys Form Load", validation_status.getLeft(), validation_status.getRight(), driver, "Add Surveys Form");

		surveysPage.fillAddSurveysFirstPage();

		operating_room_count = fakeInfoGeneratorBarebone.generateRandomNumericString(1);
		procedure_room_count = fakeInfoGeneratorBarebone.generateRandomNumericString(1);
		patient_admission_count = fakeInfoGeneratorBarebone.generateRandomNumericString(2);
		surveysPage.fillAddSurveysSecondPage(operating_room_count, procedure_room_count, patient_admission_count);

		// Test case 3
		validation_status = surveysPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Add Surveys Form Complete", !(validation_status.getLeft()), validation_status.getRight(), driver,
				"Add Surveys Form Complete");
	}

	@Test
	public void validateSearchSurveysPage() throws InterruptedException, IOException {
		landingPage.selectComponent();
		landingPage.selectGroupFollowedByFacility();
		landingPage.submitSelection();

		surveysPage.selectMenu(surveysPage.page_name);
		// Test case 4
		validation_status = surveysPage.verifyPageWithSoftAssertion(surveysPage.page_name);
		ExtentManager.ExecuteTest("Verify Surveys Page", validation_status.getLeft(), validation_status.getRight(), driver, "Surveys page");

		surveysPage.fillSearchFields(facility_id, facility_name, survey_year, survey_type);
		// Test case 5
		validation_status = surveysPage.verifySearchResult(facility_id, facility_name, survey_year, survey_type);
		ExtentManager.ExecuteTest("Verify Surveys Search Result", validation_status.getLeft(), validation_status.getRight(), driver, "Surveys search results");
	}
	
	@AfterMethod
	public void logout(){
		loginPage.logout();
	}
}