package test_suites;

import java.io.IOException;

import org.apache.commons.lang3.tuple.Pair;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import manager_objects.ExtentManager;

public class FacilityLocationsPageTest extends BaseTest {
	Pair<Boolean, String> validation_status;
	String code = "";
	String label = "";
	String bedSize = "";
	// Please fill with valid search entries
	String search_code = "";
	String search_label = "";
	String search_cdc_desc = "";
	String search_cdc_code = "";
	String search_nhsn_code = "";
	String search_bed_size = "";

	@BeforeMethod
	public void login() throws IOException, InterruptedException {
		loginPage.inputUserNameAndPassword();
		loginPage.login();
	}

	@Test
	public void validateAddFacilityLocationsPage() throws InterruptedException, IOException {
		landingPage.selectComponent();
		landingPage.selectFacility();
		landingPage.submitSelection();
		facilityPage.selectMenu(facilityPage.parent_page_name, facilityPage.location_page_name);
		// Test case 1
		validation_status = facilityPage.verifyPageWithSoftAssertion(facilityPage.location_page_name);
		ExtentManager.ExecuteTest("Verify Facility Locations Page", validation_status.getLeft(), validation_status.getRight(), driver,
				"Facility Locations page");

		facilityPage.clickAdd();
		// Test case 2
		validation_status = facilityPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Add Facility Location Form Load", validation_status.getLeft(), validation_status.getRight(), driver,
				"Add Facility Location Form");

		code = fakeInfoGeneratorBarebone.generateRandomAlphaNeumericString(8);
		label = fakeInfoGeneratorBarebone.generateRandomAlphaNeumericString(8);
		bedSize = fakeInfoGeneratorBarebone.generateRandomNumericString(4);
		facilityPage.fillAddFacilityLocation(code, label, bedSize);

		// Test case 3
		validation_status = facilityPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Add Facility Location Form Complete", !(validation_status.getLeft()), validation_status.getRight(), driver,
				"Add Facility Location Form Complete");
	}
	
	@Test
	public void validateSearchFacilityLocationsPage() throws InterruptedException, IOException {
		landingPage.selectComponent();
		landingPage.selectGroupFollowedByFacility();
		landingPage.submitSelection();

		facilityPage.selectMenu(facilityPage.parent_page_name, facilityPage.location_page_name);
		// Test case 4
		validation_status = facilityPage.verifyPageWithSoftAssertion(facilityPage.location_page_name);
		ExtentManager.ExecuteTest("Verify Facility Locations Page", validation_status.getLeft(), validation_status.getRight(), driver,
				"Facility Locations page");

		facilityPage.fillFacilityLocationSearchFields(search_code, search_label, search_cdc_desc, search_cdc_code,
				search_nhsn_code, search_bed_size);
		// Test case 5
		validation_status = facilityPage.verifyFacilityLocationSearchResult(search_code, search_label, search_cdc_desc,
				search_cdc_code, search_nhsn_code, search_bed_size);
		ExtentManager.ExecuteTest("Verify Facility Search Result", validation_status.getLeft(), validation_status.getRight(), driver,
				"Facility search results");
	}

	@AfterMethod
	public void logout() throws InterruptedException {
		loginPage.logout();
	}
}