package test_suites;

import java.io.IOException;

import org.apache.commons.lang3.tuple.Pair;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import manager_objects.ExtentManager;

public class EventsPageTest extends BaseTest {

	Pair<Boolean, String> validation_status;
	String facilityId = "";
	String lName = "";
	String fName = "";
	String mName = "";
	String patientId = "";
	String ssn = "";
	String secondaryId = "";
	String medicare = "";
	String dob = "";
	String eventNo = "";
	String eventType = "";
	String eventDate = "";
	String location = "";
	String completionStatus = "";
	String linkedEvents = "";

	@BeforeMethod
	public void login() throws IOException, InterruptedException {
		loginPage.inputUserNameAndPassword();
		loginPage.login();
	}

	@Test
	public void validateAddEventsPage() throws InterruptedException, IOException {
		landingPage.selectComponent();
		landingPage.selectFacility();
		landingPage.submitSelection();
		eventsPage.selectMenu(eventsPage.navigation_page_name);
		// Test case 1
		validation_status = eventsPage.verifyPageWithSoftAssertion(eventsPage.page_name);
		ExtentManager.ExecuteTest("Verify Events Page", validation_status.getLeft(), validation_status.getRight(), driver, "Events page");

		eventsPage.addEvent();
		// Test case 2
		validation_status = eventsPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Add Events Form Load", validation_status.getLeft(), validation_status.getRight(), driver, "Add Events Form");

    	facilityId = fakeInfoGeneratorBarebone.generateRandomNumericString(5);
		patientId = fakeInfoGeneratorBarebone.generateRandomNumericString(5);
		lName = fakeInfoGeneratorBarebone.generateRandomString(6);
		fName = fakeInfoGeneratorBarebone.generateRandomString(6);
		mName = fakeInfoGeneratorBarebone.generateRandomString(6);

		eventsPage.fillAddEventsFirstPage(facilityId, patientId, lName, fName, mName);

		ssn = fakeInfoGeneratorBarebone.generateRandomNumericString(9);
		secondaryId = fakeInfoGeneratorBarebone.generateRandomString(6);
		medicare = fakeInfoGeneratorBarebone.generateRandomString(7);
		dob = fakeInfoGeneratorBarebone.generateRandomDateString();

		eventsPage.fillAddEventsSecondPage(ssn, secondaryId, medicare, dob);
		eventsPage.fillAddEventsThirdPage();
		eventsPage.fillAddEventsFourthPage();
		eventsPage.fillAddEventsFifthPage();

		// Test case 3
		validation_status = eventsPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Add Events Form Complete", !(validation_status.getLeft()), validation_status.getRight(), driver, "Add Events Complete");

	}
	
	@Test
	public void validateSearchEventPage() throws InterruptedException, IOException {
		landingPage.selectComponent();
		landingPage.selectGroupFollowedByFacility();
		landingPage.submitSelection();

		eventsPage.selectMenu(eventsPage.navigation_page_name);
		// Test case 4
		validation_status = eventsPage.verifyPageWithSoftAssertion(eventsPage.page_name);
		ExtentManager.ExecuteTest("Verify Events Page", validation_status.getLeft(), validation_status.getRight(), driver, "Events page");

		eventsPage.fillSearchFields(eventNo, eventType, eventDate, lName, fName, patientId, location, completionStatus,
				linkedEvents);
		// Test case 5
		validation_status = eventsPage.verifySearchResult(eventNo, eventType, eventDate, lName, fName, patientId,
				location, completionStatus, linkedEvents);
		ExtentManager.ExecuteTest("Verify Events Search Result", validation_status.getLeft(), validation_status.getRight(), driver, "Events search results");
	}

	@AfterMethod
	public void logout() throws InterruptedException {
		loginPage.logout();
	}
}