package test_suites;

import java.io.IOException;

import org.apache.commons.lang3.tuple.Pair;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import manager_objects.ExtentManager;

public class AlertsPageTest extends BaseTest {

	Pair<Boolean, String> validation_status;

	@BeforeMethod
	public void login() throws IOException, InterruptedException {
        loginPage.inputUserNameAndPassword();
    	loginPage.login();
    	landingPage.selectComponent();
    	landingPage.selectFacility();
    	landingPage.submitSelection();
	}

	@Test
	public void validateAlertsPage() throws InterruptedException, IOException {
		alertsPage.selectMenu(alertsPage.page_name);
		// Test case 1
		validation_status = alertsPage.verifyPageWithSoftAssertion(alertsPage.page_name);
		ExtentManager.ExecuteTest("Verify Alerts Page", validation_status.getLeft(), validation_status.getRight(), driver, "Alerts page");

	}

	@AfterMethod
	public void logout() throws InterruptedException {
		loginPage.logout();
	}
}