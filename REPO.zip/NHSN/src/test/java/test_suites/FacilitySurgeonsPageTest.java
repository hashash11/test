package test_suites;

import java.io.IOException;

import org.apache.commons.lang3.tuple.Pair;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import manager_objects.ExtentManager;

public class FacilitySurgeonsPageTest extends BaseTest {
	Pair<Boolean, String> validation_status;
	String code = "";
	String lname = "";
	String fname = "";
	String mname = "";
	// Please fill with valid search entries
	String search_code = "";
	String search_lname = "";
	String search_fname = "";
	String search_mname = "";

	@BeforeMethod
	public void login() throws IOException, InterruptedException {
		loginPage.inputUserNameAndPassword();
		loginPage.login();
	}

	@Test
	public void validateAddFacilitySurgeosPage() throws InterruptedException, IOException {
		landingPage.selectComponent();
		landingPage.selectFacility();
		landingPage.submitSelection();
		facilityPage.selectMenu(facilityPage.parent_page_name, facilityPage.surgeons_page_name);
		// Test case 1
		validation_status = facilityPage.verifyPageWithSoftAssertion(facilityPage.surgeons_page_name);
		ExtentManager.ExecuteTest("Verify Facility Surgeons Page", validation_status.getLeft(), validation_status.getRight(), driver, "Facility Surgeons page");

		facilityPage.clickAdd();
		// Test case 2
		validation_status = facilityPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Add Facility Surgeons Form Load", validation_status.getLeft(), validation_status.getRight(), driver,
				"Add Facility Surgeons Form");

		code = fakeInfoGeneratorBarebone.generateRandomAlphaNeumericString(8);
		lname = fakeInfoGeneratorBarebone.generateRandomAlphaNeumericString(8);
		fname = fakeInfoGeneratorBarebone.generateRandomAlphaNeumericString(8);
		mname = fakeInfoGeneratorBarebone.generateRandomAlphaNeumericString(8);
		facilityPage.fillAddFacilitySurgeon(code, lname, fname, mname);

		// Test case 3
		validation_status = facilityPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Add Facility Surgeon Form Complete", !(validation_status.getLeft()), validation_status.getRight(), driver,
				"Add Facility Surgeon Form Complete");
	}
	
	@Test
	public void validateSearchFacilitySurgeosPage() throws InterruptedException, IOException {
		landingPage.selectComponent();
		landingPage.selectGroupFollowedByFacility();
		landingPage.submitSelection();

		facilityPage.selectMenu(facilityPage.parent_page_name, facilityPage.surgeons_page_name);
		// Test case 4
		validation_status = facilityPage.verifyPageWithSoftAssertion(facilityPage.surgeons_page_name);
		ExtentManager.ExecuteTest("Verify Facility Surgeons Page", validation_status.getLeft(), validation_status.getRight(), driver, "Facility Surgeons page");

		facilityPage.fillFacilitySurgeonsSearchFields(search_code, search_lname, search_fname, search_mname);
		// Test case 5
		validation_status = facilityPage.verifyFacilitySurgeonsSearchResult(search_code, search_lname, search_fname,
				search_mname);
		ExtentManager.ExecuteTest("Verify Facility Search Result", validation_status.getLeft(), validation_status.getRight(), driver,
				"Facility search results");
	}

	@AfterMethod
	public void logout() throws InterruptedException {
		loginPage.logout();
	}
}