package test_suites;

import java.io.IOException;

import org.apache.commons.lang3.tuple.Pair;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import manager_objects.ExtentManager;

public class LandingPageTest extends BaseTest {

	Pair<Boolean, String> validation_status;
	private String component = "Outpatient Procedure";
	private String group = "Romaine's Test OP Group";
	private String direct_facility = "Facility_Young_0001";
	private String facility_under_group = "All Facilities";

	@BeforeMethod
	public void login() throws IOException, InterruptedException {
		loginPage.inputUserNameAndPassword();
		loginPage.login();
	}

	@Test
	public void validateFacilitySelection() throws InterruptedException, IOException {
		landingPage.selectComponent(component);
		landingPage.selectFacility(direct_facility);
		landingPage.submitSelection();
		validation_status = landingPage.verifyFacility(direct_facility);
		// Test Case
		ExtentManager.ExecuteTest("Verify Direct Facility Selection", validation_status.getLeft(), validation_status.getRight(), driver,
				"Direct Facility Selection");
	}

	@Test
	public void validateGroupFollowedByFacilitySelection() throws InterruptedException, IOException {
		landingPage.selectComponent(component);
		landingPage.selectGroupFollowedByFacility(group, facility_under_group);
		landingPage.submitSelection();
		validation_status = landingPage.verifyFacility(facility_under_group);
		// Test Case
		ExtentManager.ExecuteTest("Verify Facility under Group Selection", validation_status.getLeft(), validation_status.getRight(), driver,
				"Facility under Group Selection");
	}

	@AfterMethod
	public void logout() throws InterruptedException {
		loginPage.logout();
	}

}