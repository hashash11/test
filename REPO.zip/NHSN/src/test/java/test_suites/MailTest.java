package test_suites;

import jakarta.mail.MessagingException;
import manager_objects.Mailer;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MailTest {

    Mailer mailer = new Mailer();

    @Test
    public void sendMail() throws MessagingException, IOException, InterruptedException {
        TimeUnit.SECONDS.sleep(10);
        ArrayList<File> files = new ArrayList<>();
        try {
            List<String> names = Stream.of(new File("src/test/java/extent_reports/screenshots").listFiles())
                    .filter(file -> !file.isDirectory())
                    .map(File::getPath)
                    .collect(Collectors.toList());

            for (String n : names) {
                files.add(new File(n));
            }

            files.add(new File("src/test/java/extent_reports/execution_report.html"));
        }
        catch (Exception e ){
            System.out.println("There are no screenshots: " + e);
        }
        byte[] buffer = new byte[1024];
        String zipFileName = ("extent_reports.zip");

        FileOutputStream fos = new FileOutputStream(zipFileName);

        ZipOutputStream zos = new ZipOutputStream(fos);

        for (int i = 0; i < files.size(); i++)
        {
            FileInputStream in = new FileInputStream(files.get(i));
            zos.putNextEntry(new ZipEntry(files.get(i).getPath().replace("src\\test\\java\\", "")));
            int len;
            while ((len = in.read(buffer)) > 0)
            {
                zos.write(buffer, 0, len);
            }
            zos.closeEntry();
            in.close();
        }
        zos.close();

        mailer.sendMail();
    }
}
