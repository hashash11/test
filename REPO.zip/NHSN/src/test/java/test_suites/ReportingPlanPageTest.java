package test_suites;

import java.io.IOException;

import org.apache.commons.lang3.tuple.Pair;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import manager_objects.ExtentManager;

public class ReportingPlanPageTest extends BaseTest {

	Pair<Boolean, String> validation_status;
	String month = "July";
	String year = "2023";
	String facilityId = "14839";

	@BeforeMethod
	public void login() throws IOException, InterruptedException {
		loginPage.inputUserNameAndPassword();
		loginPage.login();
	}

	@Test
	public void validateAddReportingPlan() throws InterruptedException, IOException {
		landingPage.selectComponent();
		landingPage.selectFacility();
		landingPage.submitSelection();
		reportingPlanPage.selectMenu(reportingPlanPage.page_name);
		// Test case 1
		validation_status = reportingPlanPage.verifyPageWithSoftAssertion(reportingPlanPage.page_name);
		ExtentManager.ExecuteTest("Verify Reporting Plan Page", validation_status.getLeft(),
				validation_status.getRight(), driver, "Reporting Plan page");

		reportingPlanPage.clickAdd();
		// Test case 2
		validation_status = reportingPlanPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Reporting Plan Form Load", validation_status.getLeft(),
				validation_status.getRight(), driver, "Reporting Plan Form");

		reportingPlanPage.fillAddReporingPlanPage();

		// Test case 3
		validation_status = reportingPlanPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Reporting Plan Form Complete", !(validation_status.getLeft()),
				validation_status.getRight(), driver, "Reporting Plan Form Complete");
	}

	@Test
	public void validateSearchReportingPlan() throws InterruptedException, IOException {
		landingPage.selectComponent();
		landingPage.selectGroupFollowedByFacility();
		landingPage.submitSelection();

		reportingPlanPage.selectMenu(reportingPlanPage.page_name);
		// Test case 4
		validation_status = reportingPlanPage.verifyPageWithSoftAssertion(reportingPlanPage.page_name);
		ExtentManager.ExecuteTest("Verify Reporting Plan Page", validation_status.getLeft(),
				validation_status.getRight(), driver, "Reporing Plan page");

		reportingPlanPage.fillSearchFields(month, year, facilityId);
		// Test case 5
		validation_status = reportingPlanPage.verifySearchResult(month, year, facilityId);
		ExtentManager.ExecuteTest("Verify Reporting Plan Search Result", validation_status.getLeft(),
				validation_status.getRight(), driver, "Reporting Plan search results");
	}

	@AfterMethod
	public void logout() throws InterruptedException {
		loginPage.logout();
	}
}