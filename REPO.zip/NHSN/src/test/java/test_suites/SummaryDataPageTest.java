package test_suites;

import java.io.IOException;

import org.apache.commons.lang3.tuple.Pair;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import manager_objects.ExtentManager;

public class SummaryDataPageTest extends BaseTest {
	Pair<Boolean, String> validation_status;
	String month;

	@BeforeMethod
	public void login() throws IOException, InterruptedException {
		loginPage.inputUserNameAndPassword();
		loginPage.login();
	}

	@Test
	public void validateSummaryDataPage() throws InterruptedException, IOException {
		landingPage.selectComponent();
		landingPage.selectFacility();
		landingPage.submitSelection();
		summaryDataPage.selectMenu(summaryDataPage.page_name);
		// Test case 1
		validation_status = summaryDataPage.verifyPageWithSoftAssertion(summaryDataPage.page_name);
		ExtentManager.ExecuteTest("Verify Summary Data Page", validation_status.getLeft(), validation_status.getRight(),
				driver, "Summary Data page");

		summaryDataPage.clickAdd();
		// Test case 2
		validation_status = summaryDataPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Add Summary Data Form Load", validation_status.getLeft(),
				validation_status.getRight(), driver, "Add Summary Data Form");

		month = fakeInfoGeneratorBarebone.generateRandomNumericString(1);
		summaryDataPage.fillAddSummaryDataPage(month);

		// Test case 3
		validation_status = summaryDataPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Add Summary Data Form Complete", !(validation_status.getLeft()),
				validation_status.getRight(), driver, "Add Summary Data Form Complete");
	}

	@AfterMethod
	public void logout() throws InterruptedException {
		loginPage.logout();
	}
}