package test_suites;

import java.io.IOException;

import org.apache.commons.lang3.tuple.Pair;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import manager_objects.ExtentManager;

public class GroupsPageTest extends BaseTest {

	Pair<Boolean, String> validation_status;
	String groupName, groupPassword;
	// Need to add valid information
	String joinGroupID = "";
	String joinGroupPassword = "";

	@BeforeMethod
	public void login() throws IOException, InterruptedException {
		loginPage.inputUserNameAndPassword();
		loginPage.login();
	}

	@Test
	public void validateGroups() throws InterruptedException, IOException {
		landingPage.selectComponent();
		landingPage.selectFacility();
		landingPage.submitSelection();
		groupsPage.selectMenu(groupsPage.page_name);
		// Test case 1
		validation_status = groupsPage.verifyPageWithSoftAssertion(groupsPage.page_name);
		ExtentManager.ExecuteTest("Verify Groups Page", validation_status.getLeft(), validation_status.getRight(),
				driver, "Groups page");

		groupName = "test " + fakeInfoGeneratorBarebone.generateRandomString(6);
		groupPassword = fakeInfoGeneratorBarebone.generateRandomString(6);
		groupsPage.addGroup(groupName, groupPassword);
		// Test case 2
		validation_status = groupsPage.verifyGroup(groupName);
		ExtentManager.ExecuteTest("Verify Added Group", validation_status.getLeft(), validation_status.getRight(),
				driver, "Newly added group");

		validation_status = groupsPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Add Group Form", validation_status.getLeft(), validation_status.getRight(),
				driver, "Add group form");

		int currentGroupCount = groupsPage.returnGroupCount();
		groupsPage.joinGroup(joinGroupID, groupPassword);
		int updatedCurrentGroupCount = groupsPage.returnGroupCount();
		// Test case 3
		if (updatedCurrentGroupCount > currentGroupCount) {
			validation_status = Pair.of(true, "");
		} else {
			validation_status = Pair.of(false, "Group was not added");
		}
		ExtentManager.ExecuteTest("Verify Joined Group", validation_status.getLeft(), validation_status.getRight(),
				driver, "Newly joined group");

		currentGroupCount = updatedCurrentGroupCount;
		groupsPage.leaveGroup(groupName);
		updatedCurrentGroupCount = groupsPage.returnGroupCount();
		// Test case 4
		if (updatedCurrentGroupCount < currentGroupCount) {
			validation_status = Pair.of(true, "");
		} else {
			validation_status = Pair.of(false, "Group was not removed");
		}
		ExtentManager.ExecuteTest("Verify Deleted Group", validation_status.getLeft(), validation_status.getRight(),
				driver, "Newly deleted group");

	}

	@AfterMethod
	public void logout() throws InterruptedException {
		loginPage.logout();
	}
}