package test_suites;

import java.io.IOException;

import org.apache.commons.lang3.tuple.Pair;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import manager_objects.ExtentManager;

public class FacilityCustomizeFormsPageTest extends BaseTest {
	Pair<Boolean, String> validation_status;
	String form_type = "";
	String form = "";
	String desc = "";
	String loc_label = "";
	// Please fill with valid search entries
	String search_form_type = "";
	String search_form = "";
	String search_form_desc = "";
	String search_form_location = "";

	@BeforeMethod
	public void login() throws IOException, InterruptedException {
		loginPage.inputUserNameAndPassword();
		loginPage.login();

	}

	@Test
	public void validateAddFacilityCustomFormsPage() throws InterruptedException, IOException {
		landingPage.selectComponent();
		landingPage.selectFacility();
		landingPage.submitSelection();
		facilityPage.selectMenu(facilityPage.parent_page_name, facilityPage.customize_forms_page_name);
		// Test case 1
		validation_status = facilityPage.verifyPageWithSoftAssertion(facilityPage.customize_forms_page_name);
		ExtentManager.ExecuteTest("Verify Facility Customize Forms Page", validation_status.getLeft(), validation_status.getRight(), driver,
				"Facility Customize Forms page");

		facilityPage.clickAdd();
		// Test case 2
		validation_status = facilityPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Add Facility Customize Forms Form Load", validation_status.getLeft(), validation_status.getRight(), driver,
				"Add Facility Customize Forms Form");

		form_type = fakeInfoGeneratorBarebone.generateRandomAlphaNeumericString(8);
		form = fakeInfoGeneratorBarebone.generateRandomAlphaNeumericString(8);
		desc = fakeInfoGeneratorBarebone.generateRandomAlphaNeumericString(8);
		loc_label = fakeInfoGeneratorBarebone.generateRandomAlphaNeumericString(8);
		facilityPage.fillAddFacilityCustomizeForm(form_type, form, desc, loc_label);

		// Test case 3
		validation_status = facilityPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Add Facility Customize Forms Form Complete", !(validation_status.getLeft()), validation_status.getRight(), driver,
				"Add Facility Customize Forms Form Complete");

	}
	
	@Test
	public void validateFacilityCustomFormsPage() throws InterruptedException, IOException {
		landingPage.selectComponent();
		landingPage.selectGroupFollowedByFacility();
		landingPage.submitSelection();

		facilityPage.selectMenu(facilityPage.parent_page_name, facilityPage.customize_forms_page_name);
		// Test case 4
		validation_status = facilityPage.verifyPageWithSoftAssertion(facilityPage.surgeons_page_name);
		ExtentManager.ExecuteTest("Verify Facility Customize Forms Page", validation_status.getLeft(), validation_status.getRight(), driver,
				"Facility Customize Forms page");

		facilityPage.fillFacilityCustomizeFormsSearchFields(search_form_type, search_form, search_form_desc,
				search_form_location);
		// Test case 5
		validation_status = facilityPage.verifyFacilityCustomizeFormsSearchResult(search_form_type, search_form,
				search_form_desc, search_form_location);
		ExtentManager.ExecuteTest("Verify Facility Search Result", validation_status.getLeft(), validation_status.getRight(), driver,
				"Facility search results");
	}
	
	@AfterMethod
	public void logout() throws InterruptedException {
		loginPage.logout();
	}
}