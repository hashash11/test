package test_suites;

import java.io.IOException;

import org.apache.commons.lang3.tuple.Pair;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import manager_objects.ExtentManager;

public class PatientPageTest extends BaseTest {

	Pair<Boolean, String> validation_status;
	String facilityId = "14839";
	String patientId = "AAA89472";
	String lName = "";
	String fName = "";
	String mName = "";
	String ssn = "";
	String secondaryId = "";
	String medicare = "";
	String gender = "M";
	String dob = "10/10/2019";
	String comments = "";

	@BeforeMethod
	public void login() throws IOException, InterruptedException {
		loginPage.inputUserNameAndPassword();
		loginPage.login();

	}

	@Test
	public void validateAddPatientPage() throws InterruptedException, IOException {
		landingPage.selectComponent();
		landingPage.selectFacility();
		landingPage.submitSelection();
		patientPage.selectMenu(patientPage.page_name);
		// Test case 1
		validation_status = patientPage.verifyPageWithSoftAssertion(patientPage.page_name);
		ExtentManager.ExecuteTest("Verify Patient Page", validation_status.getLeft(), validation_status.getRight(), driver, "Patient page");

		patientPage.clickAdd();
		// Test case 2
		validation_status = patientPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Add Patient Form Load", validation_status.getLeft(), validation_status.getRight(), driver, "Add Patient Form");

//    	facilityId = fakeInfoGeneratorBarebone.generateRandomNumericString(5);
//    	patientId = fakeInfoGeneratorBarebone.generateRandomNumericString(5);
		lName = fakeInfoGeneratorBarebone.generateRandomString(6);
		fName = fakeInfoGeneratorBarebone.generateRandomString(6);
		mName = fakeInfoGeneratorBarebone.generateRandomString(6);

		patientPage.fillAddPatientFirstPage(facilityId, patientId, lName, fName, mName);

		ssn = fakeInfoGeneratorBarebone.generateRandomNumericString(9);
		secondaryId = fakeInfoGeneratorBarebone.generateRandomString(6);
		medicare = fakeInfoGeneratorBarebone.generateRandomString(7);
		dob = fakeInfoGeneratorBarebone.generateRandomDateString();

		patientPage.fillAddPatientSecondPage(ssn, secondaryId, medicare, dob);

		comments = fakeInfoGeneratorBarebone.generateRandomString(30);
		patientPage.fillAddPatientThirdPage(comments);

		// Test case 3
		validation_status = patientPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Add Patient Form Complete", !(validation_status.getLeft()), validation_status.getRight(), driver,
				"Add Patient Form Complete");
			
	}
	
	@Test
	public void validateSearchPatientPage() throws InterruptedException, IOException {
		landingPage.selectComponent();
		landingPage.selectGroupFollowedByFacility();
		landingPage.submitSelection();

		patientPage.selectMenu(patientPage.page_name);
		// Test case 4
		validation_status = patientPage.verifyPageWithSoftAssertion(patientPage.page_name);
		ExtentManager.ExecuteTest("Verify Patient Page", validation_status.getLeft(), validation_status.getRight(), driver, "Patient page");

    	patientPage.fillSearchFields(facilityId, patientId, lName, fName, ssn, gender, dob, secondaryId);
    	// Test case 5
    	validation_status = patientPage.verifySearchResult(facilityId, patientId, lName, fName, ssn, gender, dob, secondaryId);
    	ExtentManager.ExecuteTest("Verify Patients Search Result",validation_status.getLeft(), validation_status.getRight(), driver, "Patients search results");
	}

	@AfterMethod
	public void logout() throws InterruptedException {
		loginPage.logout();
	}
}