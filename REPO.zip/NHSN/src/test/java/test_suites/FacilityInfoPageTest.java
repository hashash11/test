package test_suites;

import java.io.IOException;

import org.apache.commons.lang3.tuple.Pair;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import manager_objects.ExtentManager;

public class FacilityInfoPageTest extends BaseTest {
	Pair<Boolean, String> validation_status;

	@BeforeMethod
	public void login() throws IOException, InterruptedException {
		loginPage.inputUserNameAndPassword();
		loginPage.login();
		landingPage.selectComponent();
		landingPage.selectFacility();
		landingPage.submitSelection();
	}

	@Test
	public void validateFacilityInfoPage() throws InterruptedException, IOException {
		facilityPage.selectMenu(facilityPage.parent_page_name, facilityPage.facitlity_info_navigation_page_name);
		// Test case 1
		validation_status = facilityPage.verifyPageWithSoftAssertion(facilityPage.facility_info_page_name);
		ExtentManager.ExecuteTest("Verify Facility Information Page", validation_status.getLeft(), validation_status.getRight(), driver,
				"Facility Information page");
	}

	@AfterMethod
	public void logout() throws InterruptedException {
		loginPage.logout();
	}
}