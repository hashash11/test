package test_suites;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import io.github.bonigarcia.wdm.WebDriverManager;
import manager_objects.ConfigManager;
import manager_objects.ExtentManager;
import manager_objects.FakeInfoGeneratorBarebone;
import page_objects.AlertsPage;
import page_objects.EventsPage;
import page_objects.FacilityPage;
import page_objects.GroupsPage;
import page_objects.LandingPage;
import page_objects.LoginPage;
import page_objects.PatientPage;
import page_objects.ReportingPlanPage;
import page_objects.SummaryDataPage;
import page_objects.SurveysPage;
import page_objects.UsersPage;
import page_objects.ProceduresPage;

public class BaseTest {
	protected WebDriver driver;
	ChromeOptions chromeOptions = new ChromeOptions();
	EdgeOptions edgeOptions = new EdgeOptions();
	FirefoxOptions firefoxOptions = new FirefoxOptions();
	FakeInfoGeneratorBarebone fakeInfoGeneratorBarebone;
	LoginPage loginPage;
	LandingPage landingPage;
	ReportingPlanPage reportingPlanPage;
	PatientPage patientPage;
	GroupsPage groupsPage;
	AlertsPage alertsPage;
	ProceduresPage proceduresPage;
	SummaryDataPage summaryDataPage;
	EventsPage eventsPage;
	SurveysPage surveysPage;
	UsersPage usersPage;
	FacilityPage facilityPage;

	private String URL = ConfigManager.getAppURL();
	public String browser = ConfigManager.getBrowser();
	public Boolean headless = ConfigManager.getHeadless();

	@BeforeMethod
	public void setUp() {
		// Initialize WebDriver, Page Objects and ExtentReports
		if (browser.trim().equals("Chrome")) {
			WebDriverManager.chromedriver().setup();
			if (headless) {
				ChromeOptions options = new ChromeOptions();
				options.addArguments("--headless");
				options.addArguments("--disable-gpu");

				driver = new ChromeDriver(options);
			} else {
				driver = new ChromeDriver();
			}
		} else if (browser.trim().equals("Edge")) {
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
		} else if (browser.trim().equals("Firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		} else {
			throw new IllegalArgumentException("Unsupported browser: " + browser);
		}
		fakeInfoGeneratorBarebone = new FakeInfoGeneratorBarebone();
		loginPage = new LoginPage(driver);
		landingPage = new LandingPage(driver);
		reportingPlanPage = new ReportingPlanPage(driver);
		patientPage = new PatientPage(driver);
		groupsPage = new GroupsPage(driver);
		alertsPage = new AlertsPage(driver);
		proceduresPage = new ProceduresPage(driver);
		summaryDataPage = new SummaryDataPage(driver);
		eventsPage = new EventsPage(driver);
		surveysPage = new SurveysPage(driver);
		usersPage = new UsersPage(driver);
		facilityPage = new FacilityPage(driver);
		driver.get(URL);
		driver.manage().window().maximize();
	}

	@AfterMethod
	public void tearDown() {
		// Close WebDriver and flush ExtentReports
		driver.quit();
		ExtentManager.completeTest();
	}
}