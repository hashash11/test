package test_suites;

import java.io.IOException;

import org.apache.commons.lang3.tuple.Pair;
import org.testng.annotations.Test;

import manager_objects.ConfigManager;
import manager_objects.ExtentManager;

public class LoginPageTest extends BaseTest {

	private String userName = ConfigManager.getUsername();
	private String passWord = ConfigManager.getPassword();

	Pair<Boolean, String> validation_status;

	@Test
	public void validateLogin() throws InterruptedException, IOException {
		validation_status = loginPage.verifyPageTitle("NHSN 0.0.1");
		// Test Case
		ExtentManager.ExecuteTest("Verify Login Page Navigation", validation_status.getLeft(), validation_status.getRight(), driver, "Login Page Title");
		validation_status = loginPage.verifyLoginPage();
		// Test Case
		ExtentManager.ExecuteTest("Verify Login Page Content", validation_status.getLeft(), validation_status.getRight(), driver, "Login Page Content");
		loginPage.inputUserNameAndPassword(userName, passWord);
		loginPage.login();
		validation_status = loginPage.verifySuccessfulLogin(userName);
		// Test Case
		ExtentManager.ExecuteTest("Verify Successful login", validation_status.getLeft(), validation_status.getRight(), driver, "Logged in Successfully");
	}
}