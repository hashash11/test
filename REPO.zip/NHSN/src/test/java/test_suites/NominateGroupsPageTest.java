package test_suites;

import java.io.IOException;

import org.apache.commons.lang3.tuple.Pair;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import manager_objects.ExtentManager;

public class NominateGroupsPageTest extends BaseTest {
	Pair<Boolean, String> validation_status;
	String groupName, randomAlphaNeumericInputString, randomNeumericInputString, randomAlphaInputString, prefixString ;
	String existingEmail = "ryf0@cdc.gov";
	String newEmail = "test@cdc.gov";

	@BeforeMethod
	public void login() throws IOException, InterruptedException {
		loginPage.inputUserNameAndPassword();
		loginPage.login();
		landingPage.selectComponent();
		landingPage.selectFacility();
		landingPage.submitSelection();
	}

	@Test
	public void validateNominateGroupsPageExisting() throws InterruptedException, IOException {
		groupsPage.selectMenu(groupsPage.page_name);
		// Test case 1
		validation_status = groupsPage.verifyPageWithSoftAssertion(groupsPage.page_name);
		ExtentManager.ExecuteTest("Verify Groups Page", validation_status.getLeft(), validation_status.getRight(), driver, "Groups page");
		
		groupName = "test " + fakeInfoGeneratorBarebone.generateRandomNumericString(6);

		groupsPage.nominateGroupExistingUser(groupName);
	}
	
	@Test
	public void validateNominateGroupsPageNew() throws InterruptedException, IOException {
		groupsPage.selectMenu(groupsPage.page_name);
		// Test case 1
		validation_status = groupsPage.verifyPageWithSoftAssertion(groupsPage.page_name);
		ExtentManager.ExecuteTest("Verify Groups Page", validation_status.getLeft(), validation_status.getRight(), driver, "Groups page");
		
		groupName = "test " + fakeInfoGeneratorBarebone.generateRandomNumericString(6);
		randomAlphaNeumericInputString = "test " + fakeInfoGeneratorBarebone.generateRandomNumericString(8);
		randomNeumericInputString = fakeInfoGeneratorBarebone.generateRandomNumericString(3);
		randomAlphaInputString = fakeInfoGeneratorBarebone.generateRandomString(5);
		prefixString = fakeInfoGeneratorBarebone.generateRandomString(2);
		
		groupsPage.nominateGroupNewUser(groupName, newEmail,  randomAlphaNeumericInputString, randomNeumericInputString, randomAlphaInputString, prefixString);
	}

	@AfterMethod
	public void logout() throws InterruptedException {
		loginPage.logout();
	}
}