package test_suites;

import java.io.IOException;

import org.apache.commons.lang3.tuple.Pair;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import manager_objects.ExtentManager;

public class UsersPageTest extends BaseTest {
	Pair<Boolean, String> validation_status;
	String user_id, email, prefix, first_name, middle_name, last_name, title = "";
	String password = "";
	String address_1, address_2, address_3, city, zipcode, zipcode_ext = "";
	String phone_number, extension, fax_number, home_phone_number, home_extension, beeper = "";
	// Please fill with valid search entries
	String search_name = "";
	String search_title = "";
	String search_user_id = "";
	String search_email = "";
	String search_user_type = "";
	String search_active = "";

	@BeforeMethod
	public void login() throws IOException, InterruptedException {
		loginPage.inputUserNameAndPassword();
		loginPage.login();
	}

	@Test
	public void validateAddUsersPage() throws InterruptedException, IOException {
		landingPage.selectComponent();
		landingPage.selectFacility();
		landingPage.submitSelection();
		usersPage.selectMenu(usersPage.page_name);
		// Test case 1
		validation_status = usersPage.verifyPageWithSoftAssertion(usersPage.page_name);
		ExtentManager.ExecuteTest("Verify Users Page", validation_status.getLeft(), validation_status.getRight(),
				driver, "Users page");

		usersPage.clickAdd();
		// Test case 2
		validation_status = usersPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Add User Form Load", validation_status.getLeft(),
				validation_status.getRight(), driver, "Add User Form");

		user_id = fakeInfoGeneratorBarebone.generateRandomAlphaNeumericString(5);
		email = "ryf0@cdc.gov";
		prefix = fakeInfoGeneratorBarebone.generateRandomString(3);
		first_name = fakeInfoGeneratorBarebone.generateRandomString(6);
		middle_name = fakeInfoGeneratorBarebone.generateRandomString(6);
		last_name = fakeInfoGeneratorBarebone.generateRandomString(8);
		title = fakeInfoGeneratorBarebone.generateRandomString(3);
		usersPage.fillAddUserFirstPage(user_id, email, prefix, first_name, middle_name, last_name, title);

		password = fakeInfoGeneratorBarebone.generateRandomAlphaNeumericString(8);
		usersPage.fillAddUserSecondPage(password);

		address_1 = fakeInfoGeneratorBarebone.generateRandomString(6);
		address_2 = fakeInfoGeneratorBarebone.generateRandomString(6);
		address_3 = fakeInfoGeneratorBarebone.generateRandomString(6);
		city = fakeInfoGeneratorBarebone.generateRandomString(6);
		zipcode = fakeInfoGeneratorBarebone.generateRandomNumericString(6);
		zipcode_ext = fakeInfoGeneratorBarebone.generateRandomNumericString(3);
		usersPage.fillAddUserThirdPage(address_1, address_2, address_3, city, zipcode, zipcode_ext);

		phone_number = fakeInfoGeneratorBarebone.generateRandomNumericString(9);
		extension = fakeInfoGeneratorBarebone.generateRandomNumericString(4);
		fax_number = fakeInfoGeneratorBarebone.generateRandomNumericString(9);
		home_phone_number = fakeInfoGeneratorBarebone.generateRandomNumericString(9);
		home_extension = fakeInfoGeneratorBarebone.generateRandomNumericString(4);
		beeper = fakeInfoGeneratorBarebone.generateRandomNumericString(9);
		usersPage.fillAddUserFourthPage(phone_number, extension, fax_number, home_phone_number, home_extension, beeper);

		// Test case 3
		validation_status = usersPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Add User Form Complete", !(validation_status.getLeft()),
				validation_status.getRight(), driver, "Add User Form Complete");
	}

	@Test
	public void validateSearchUsersPage() throws InterruptedException, IOException {
		landingPage.selectComponent();
		landingPage.selectGroupFollowedByFacility();
		landingPage.submitSelection();

		usersPage.selectMenu(usersPage.page_name);
		// Test case 4
		validation_status = usersPage.verifyPageWithSoftAssertion(usersPage.page_name);
		ExtentManager.ExecuteTest("Verify Users Page", validation_status.getLeft(), validation_status.getRight(),
				driver, "Users page");

		usersPage.fillSearchFields(search_name, search_title, search_user_id, search_email, search_user_type,
				search_active);
		// Test case 5
		validation_status = usersPage.verifySearchResult(search_name, search_title, search_user_id, search_email,
				search_user_type, search_active);
		ExtentManager.ExecuteTest("Verify Users Search Result", validation_status.getLeft(),
				validation_status.getRight(), driver, "Users search results");
	}

	@AfterMethod
	public void logout() throws InterruptedException {
		loginPage.logout();
	}
}