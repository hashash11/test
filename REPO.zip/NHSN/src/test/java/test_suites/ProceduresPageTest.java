package test_suites;

import java.io.IOException;

import org.apache.commons.lang3.tuple.Pair;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import manager_objects.ExtentManager;

public class ProceduresPageTest extends BaseTest {

	Pair<Boolean, String> validation_status;
	String facilityId, patientId, lName, fName, mName = "";
	String ssn, secondaryId, medicare, dob = "";
	String hours, mins, height, weight = "";
	String comments = "";
	String linkedEvents, completionStatus, procedureDate, cptCode, procedureCode, procedureNo = "";

	@BeforeMethod
	public void login() throws IOException, InterruptedException {
		loginPage.inputUserNameAndPassword();
		loginPage.login();
	}

	@Test
	public void validateAddProceduresPage() throws InterruptedException, IOException {
		landingPage.selectComponent();
		landingPage.selectFacility();
		landingPage.submitSelection();
		proceduresPage.selectMenu(proceduresPage.navigation_page_name);
		// Test case 1
		validation_status = proceduresPage.verifyPageWithSoftAssertion(proceduresPage.page_name);
		ExtentManager.ExecuteTest("Verify Procedures Page", validation_status.getLeft(), validation_status.getRight(), driver, "Procedures page");

		proceduresPage.clickAdd();
		// Test case 2
		validation_status = proceduresPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Add Procedures Form Load", validation_status.getLeft(), validation_status.getRight(), driver, "Add Proceuderes Form");

//    	facilityId = fakeInfoGeneratorBarebone.generateRandomNumericString(5);
//    	patientId = fakeInfoGeneratorBarebone.generateRandomNumericString(5);
		lName = fakeInfoGeneratorBarebone.generateRandomString(6);
		fName = fakeInfoGeneratorBarebone.generateRandomString(6);
		mName = fakeInfoGeneratorBarebone.generateRandomString(6);

		proceduresPage.fillAddProceduresFirstPage(facilityId, patientId, lName, fName, mName);

		ssn = fakeInfoGeneratorBarebone.generateRandomNumericString(9);
		secondaryId = fakeInfoGeneratorBarebone.generateRandomString(6);
		medicare = fakeInfoGeneratorBarebone.generateRandomString(7);
		dob = fakeInfoGeneratorBarebone.generateRandomDateString();

		proceduresPage.fillAddProceduresSecondPage(ssn, secondaryId, medicare, dob);

		proceduresPage.fillAddProceduresThirdPage();

		hours = fakeInfoGeneratorBarebone.generateRandomNumericString(1);
		mins = fakeInfoGeneratorBarebone.generateRandomNumericString(1);
		height = fakeInfoGeneratorBarebone.generateRandomNumericString(2);
		weight = fakeInfoGeneratorBarebone.generateRandomNumericString(2);

		proceduresPage.fillAddProceduresFourthPage(hours, mins, height, weight);

		comments = fakeInfoGeneratorBarebone.generateRandomAlphaNeumericString(40);

		proceduresPage.fillAddProcedureFifthPage(comments);

		// Test case 3
		validation_status = proceduresPage.verifyFormLoad();
		ExtentManager.ExecuteTest("Verify Add Procedures Form Complete", !(validation_status.getLeft()), validation_status.getRight(), driver,
				"Add Patient Procedures Complete");
	}
	
	@Test
	public void validateSearchProceduresPage() throws InterruptedException, IOException {
		landingPage.selectComponent();
		landingPage.selectGroupFollowedByFacility();
		landingPage.submitSelection();

		proceduresPage.selectMenu(proceduresPage.navigation_page_name);
		// Test case 4
		validation_status = proceduresPage.verifyPageWithSoftAssertion(proceduresPage.page_name);
		ExtentManager.ExecuteTest("Verify Procedures Page", validation_status.getLeft(), validation_status.getRight(), driver, "Procedures page");

		proceduresPage.fillSearchFields(procedureNo, procedureCode, cptCode, procedureDate, lName, fName, patientId,
				completionStatus, linkedEvents);
		// Test case 5
		validation_status = proceduresPage.verifySearchResult(procedureNo, procedureCode, cptCode, procedureDate, lName,
				fName, patientId, completionStatus, linkedEvents);
		ExtentManager.ExecuteTest("Verify Procedures Search Result", validation_status.getLeft(), validation_status.getRight(), driver,
				"Procedures search results");
	}

	@AfterMethod
	public void logout() throws InterruptedException {
		loginPage.logout();
	}
}