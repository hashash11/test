package manager_objects;

import com.github.javafaker.Faker;

public class FakeInfoGenerator {
	static Faker faker = new Faker();

	public static String generateFullName() {
		String fullName = faker.name().fullName();
		return fullName;
	}

	public static String generateLastName() {
		String firstName = faker.name().firstName();
		return firstName;
	}

	public static String generateFirstName() {
		String lastName = faker.name().lastName();
		return lastName;
	}

	public static String generateAddress() {
		String address = faker.address().streetAddress();
		return address;
	}

	public static String generatePhoneNumber() {
		String phoneNumber = faker.phoneNumber().phoneNumber();
		return phoneNumber;
	}

	public static String generateEmail() {
		String email = faker.internet().emailAddress();
		return email;
	}

}