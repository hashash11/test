package manager_objects;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Properties;

import com.google.common.io.Files;
import jakarta.mail.MessagingException;
import jakarta.mail.Multipart;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.internet.MimeMultipart;

public class Mailer {

    public void sendMail() throws MessagingException, IOException {
        //provide sender's email ID
        String from = "nhsn@cdc.gov";

        //provide Mailtrap's host address
        String host = "smtpgw.cdc.gov";

        //get html as body text
        File f = new File("target/site/surefire-report.html");
        String content = "";
        if(f.exists() && !f.isDirectory()) {
             content = Files.asCharSource(f, StandardCharsets.UTF_8).read();
            // do something
        }
        else {
            content = "<H1>Sure Fire Report Unavailable</h1>";
        }
        //Create Email attach email body
        Multipart attachment = new MimeMultipart();
        MimeBodyPart part = new MimeBodyPart();
        part.setContent(content, "text/html; charset=utf-8");
        attachment.addBodyPart(part);

        //Attach file to email
        part = new MimeBodyPart();
        part.attachFile("../NHSN/extent_reports.zip");
        attachment.addBodyPart(part);


        //configure Mailtrap's SMTP server details
        Properties props = new Properties();
        props.put("mail.smtp.auth", "false");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);

        //create the Session object
        Session session = Session.getDefaultInstance(props);
        MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(from));
        message.setRecipient(MimeMessage.RecipientType.TO, new InternetAddress(System.getProperty("useremail")));
        message.setSubject("Notification");
        message.setContent(attachment);
        message.setSentDate(new Date());
        Transport.send(message);

    }
}

