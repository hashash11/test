package manager_objects;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentManager {
	public static ExtentReports extentReports = new ExtentReports();
	public static boolean first_execution = false;
	
	public static ExtentReports createExtentReports() {
		if (first_execution == false) {
			extentReports.setSystemInfo("Tecnology", "TestNG, Maven, Extent, Selenium Webdriver");
			extentReports.setSystemInfo("Author", "Ryan Hossain");
			first_execution = true;
		}
		ExtentSparkReporter apark = new ExtentSparkReporter("src/test/java/extent_reports/execution_report.html");
		apark.config().setReportName("Test Automation");
		extentReports.attachReporter(apark);
		return extentReports;
	}

	public static String capture(WebDriver driver) throws IOException, IOException {
		File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File Dest = new File("src/test/java/extent_reports/screenshots/" + System.currentTimeMillis() + ".png");
		String errflpath = Dest.getAbsolutePath();
		FileUtils.copyFile(srcFile, Dest);
		return errflpath;
	}

	public static void ExecuteTest(String test_case, Boolean validated, String exception, WebDriver driver,
			String element_name) throws IOException {
		ExtentReports extent = ExtentManager.createExtentReports();
		ExtentTest test = extent.createTest(test_case);
		if (validated == true) {
			test.pass(element_name + " has been verified");
		} else {
			test.log(Status.FAIL, element_name + " could not be verified");
			test.log(Status.INFO, "<b>Error log: </b>" + exception);
			test.addScreenCaptureFromPath(capture(driver));
		}
	}

	public static void completeTest() {
		extentReports.flush();
	}

}
