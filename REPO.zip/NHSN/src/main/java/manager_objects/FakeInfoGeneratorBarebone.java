package manager_objects;

import java.util.Random;

public class FakeInfoGeneratorBarebone {

	public String generateRandomString(int length) {
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
		StringBuilder randomString = new StringBuilder();

		Random random = new Random();

		for (int i = 0; i < length; i++) {
			int randomIndex = random.nextInt(characters.length());
			char randomChar = characters.charAt(randomIndex);
			randomString.append(randomChar);
		}

		return randomString.toString();
	}

	public String generateRandomNumericString(int length) {
		String characters = "0123456789";
		StringBuilder randomString = new StringBuilder();

		Random random = new Random();

		for (int i = 0; i < length; i++) {
			int randomIndex = random.nextInt(characters.length());
			char randomChar = characters.charAt(randomIndex);
			randomString.append(randomChar);
		}

		return randomString.toString();
	}

	public String generateRandomAlphaNeumericString(int length) {
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		StringBuilder randomString = new StringBuilder();

		Random random = new Random();

		for (int i = 0; i < length; i++) {
			int randomIndex = random.nextInt(characters.length());
			char randomChar = characters.charAt(randomIndex);
			randomString.append(randomChar);
		}

		return randomString.toString();
	}

	public String generateRandomDateString() {

		Random random = new Random();

		int month = random.nextInt(12) + 1;
		int day = random.nextInt(28) + 1;
		int year = random.nextInt(2023 - 1940 + 1) + 1940;

		return String.format("%02d/%02d/%04d", month, day, year);
	}

}
