package page_objects;

import java.io.IOException;
import java.util.List;

import org.apache.commons.lang3.tuple.Pair;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import manager_objects.ExtentManager;

public class GroupsPage extends BasePage {

	@FindBy(xpath = "//form")
	private WebElement groupsForm;

	@FindBy(xpath = "//span[text()=\"Add Group\"]/parent::button")
	private WebElement addGroupButton;

	@FindBy(xpath = "//span[text()=\"Join Group\"]/parent::button")
	private WebElement joinGroupButton;

	@FindBy(xpath = "(//span[text()=\"Submit\"]/parent::button)[1]")
	private WebElement submitButton;

	@FindBy(xpath = "(//span[text()=\"Submit\"]/parent::button)[2]")
	private WebElement secondarySubmitButton;

	@FindBy(xpath = "//div[@class=\"group-section-buttons\"]//span[text()=\"Add Group\"]/parent::button")
	private WebElement addGrounpSubmitButton;

	@FindBy(xpath = "//div[@class=\"group-section-buttons\"]//span[text()=\"Join Group\"]/parent::button")
	private WebElement joinGroupSubmitButton;

	@FindBy(xpath = "//span[text()=\"Nominate Group\"]/parent::button")
	private WebElement nominateGroupButton;

	// default values
	public String page_name = "Groups";

	public GroupsPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	public void addGroup(String groupName, String groupPassword) {
		try {
			super.webElementClick("Add Group", addGroupButton);
			super.Sleep();
			super.fillInputBoxInTableByLabel("Enter Group Name", groupName);
			super.fillInputBoxInTableByLabel("Enter Group Password", groupPassword);
			super.webElementClick("Add Group Submit Button", addGrounpSubmitButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured addGroup");
		}
	}

	public void joinGroup(String groupId, String groupPassword) {
		try {
			super.webElementClick("Join Group", joinGroupButton);
			super.Sleep();
			// additional validation
			super.fillInputBoxInTableByLabel("Enter Group ID", groupId);
			super.fillInputBoxInTableByLabel("Enter Group Password", groupPassword);
			super.webElementClick("Join Group Submit Button", joinGroupSubmitButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured joinGroup");
		}
	}

	public void nominateGroupExistingUser(String groupName, String email) {
		try {
			super.webElementClick("Nominate Group", nominateGroupButton);
			super.Sleep();
			super.fillInputBoxInTableByLabel("Group Name:", groupName);
			super.openDropdownAndSelectRandomOptionInDropdown("Group Type:");
			super.Sleep();
			super.clickByXpath("//label[text()=\"Create new NHSN user\"]/preceding-sibling::input");
			super.Sleep();
			super.fillInputBoxInTableByLabel("E-mail:", email);
			super.webElementClick("Submit Button", submitButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured nominateGroupExistingUser");
		}
	}

	public void nominateGroupExistingUser(String groupName) {
		try {
			super.webElementClick("Nominate Group", nominateGroupButton);
			super.Sleep();
			super.fillInputBoxInTableByLabel("Group Name:", groupName);
			super.openDropdownAndSelectRandomOptionInDropdown("Group Type:");
			super.Sleep();
			super.clickByXpath("//label[text()=\"Create new NHSN user\"]/preceding-sibling::input");
			super.Sleep();
			super.fillInputBoxInTableByLabel("E-mail:", "ryf0@cdc.gov");
			super.webElementClick("Submit Button", submitButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured nominateGroupExistingUser");
		}
	}

	public void nominateGroupNewUser(String groupName, String newEmail, String randomAlphaNeumericInputString,
			String randomNeumericInputString, String randomAlphaInputString, String prefixString) {
		try {
			super.webElementClick("Nominate Group", nominateGroupButton);
			super.Sleep();
			super.fillInputBoxInTableByLabel("Group Name:", groupName);
			super.openDropdownAndSelectRandomOptionInDropdown("Group Type:");
			super.Sleep();
			super.clickByXpath("//label[text()=\"Use existing NHSN user\"]/preceding-sibling::input");
			super.Sleep();

			super.fillInputBoxInTableByLabel("E-mail Address:", newEmail);
			super.fillInputBoxInTableByLabel("Prefix:", prefixString);
			super.fillInputBoxInTableByLabel("First Name:", randomAlphaInputString);
			super.fillInputBoxInTableByLabel("Middle Name:", randomAlphaInputString);
			super.fillInputBoxInTableByLabel("Last Name:", randomAlphaInputString);
			super.fillInputBoxInTableByLabel("Title:", randomAlphaInputString);
			super.openDropdownAndSelectRandomOptionInDropdown("User Active:");
			super.openDropdownAndSelectRandomOptionInDropdown("User Type:");

			super.fillInputBoxInTableByLabel("Enter New Password for user:", randomAlphaNeumericInputString);
			super.fillInputBoxInTableByLabel("Re-enter New Password for user:", randomAlphaNeumericInputString);

			super.fillInputBoxInTableByLabel("Address, line 1:", randomAlphaInputString);
			super.fillInputBoxInTableByLabel("Address, line 2:", randomAlphaInputString);
			super.fillInputBoxInTableByLabel("Address, line 3:", randomAlphaInputString);
			super.fillInputBoxInTableByLabel("City:", randomAlphaInputString);
			super.openDropdownAndSelectRandomOptionInDropdown("State:");
			super.openDropdownAndSelectRandomOptionInDropdown("County:");
			super.fillInputBoxInTableByLabel("Zip Code:", randomNeumericInputString);
			super.fillInputBoxInTableByLabel("Zip Code Ext:", randomNeumericInputString);

			super.fillInputBoxInTableByLabel("Phone Number:", randomNeumericInputString);
			super.fillInputBoxInTableByLabel("Extension:", randomNeumericInputString);
			super.fillInputBoxInTableByLabel("Fax Number:", randomNeumericInputString);
			super.fillInputBoxInTableByLabel("Home Phone Number:", randomNeumericInputString);
			super.fillInputBoxInTableByLabel("Home Extension:", randomNeumericInputString);
			super.fillInputBoxInTableByLabel("Beeper:", randomNeumericInputString);

			super.webElementClick("Submit Button", submitButton);
			super.Sleep();
			super.webElementClick("Secondary Submit Button", secondarySubmitButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured nominateGroupNewUser");
		}
	}

	public Pair<Boolean, String> verifyGroup(String groupName) {
		try {
			boolean status = driver.findElement(By.xpath(String.format("//div[text()=\"%s\"]", groupName)))
					.isDisplayed();
			if (status) {
				return Pair.of(true, "");
			} else {
				return Pair.of(false, "Group Page was not displayed");
			}
		} catch (Exception e) {
			return Pair.of(false, "Group Page was not displayed<br>" + e.toString());
		}
	}

	public int returnGroupCount() {
		try {
			List<WebElement> elements = driver
					.findElements(By.xpath("//div[contains(@class, 'group-detail-card-title')]"));
			return elements.size();
		} catch (Exception e) {
			return 0;
		}
	}

	public void leaveGroup(String groupName) throws IOException {
		String verification_string = "Click <b> Leave Group</b> button";
		try {
			WebElement leaveGroupButton = driver.findElement(By.xpath(String
					.format("//div[text()=\"%s\"]/following-sibling::div//button[@title=\"Leave Group\"]", groupName)));
			super.webElementClick("Leave Group Button", leaveGroupButton);
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}
}
