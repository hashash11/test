package page_objects;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.commons.lang3.tuple.Pair;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ReportingPlanPage extends BasePage {

	@FindBy(xpath = "//form")
	private WebElement reportingPlanForm;

	@FindBy(xpath = "//button/span[text()=\"Save\"]")
	private WebElement saveButton;

	@FindBy(xpath = "//label[text()=\"No NHSN Outpatient Reporting this month\"]/preceding-sibling::input")
	private WebElement checkbox1;

	@FindBy(xpath = "//label[text()=\"Same Day Outcome Measures\"]/preceding-sibling::input")
	private WebElement checkbox2;

	// default values
	public String page_name = "Reporting Plan";

	public ReportingPlanPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	// fills the search input boxes in Reporting Plan
	// Pass the month, year and facility id as paramater
	public void fillSearchFields(String month, String year, String facilityId)
			throws InterruptedException, IOException {
		try {
			// super.fillInputBoxInTableByTableHeader("Month", month);
			// super.fillInputBoxInTableByTableHeader("Year", year);
			super.fillInputBoxInTableByTableHeader("Facility ID", facilityId);
			super.Sleep(2);
		} catch (Exception e) {
			System.out.println("Error occured fillSearchFields");
		}
	}

	// verifies the search result in the table
	// Pass the month, year and facility id to verify as paramater
	public Pair<Boolean, String> verifySearchResult(String month, String year, String facilityId) {
		try {
			ArrayList<Boolean> validation = new ArrayList<Boolean>();
			if (month.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Month", month));
			}
			if (year.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Year", year));
			}
			if (facilityId.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Facility ID", facilityId));
			}

			Boolean flag = true;
			for (boolean value : validation) {
				if (value == false) {
					flag = false;
					break;
				}
			}
			if (flag == true) {
				return Pair.of(true, "");
			} else {
				return Pair.of(false, "The search result did not match with the provided input.");
			}
		} catch (Exception e) {
			return Pair.of(false, e.toString());
		}
	}

	public void fillAddReporingPlanPage() {
		try {
			super.openDropdownAndSelectRandomOptionInDropdown("Month:");
			super.openDropdownAndSelectRandomOptionInDropdown("Year:");
//			checkbox1.click();
			super.webElementClick("Second Check Box", checkbox2);
			super.webElementClick("Save Button", saveButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddReporingPlanPage");
		}
	}
}
