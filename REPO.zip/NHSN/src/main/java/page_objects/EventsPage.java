package page_objects;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.tuple.Pair;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import manager_objects.ExtentManager;

public class EventsPage extends BasePage {

	@FindBy(xpath = "//button/span[text()=\"Next\"]")
	private WebElement nextButton;

	@FindBy(xpath = "//button/span[text()=\"Submit\"]")
	private WebElement submitButton;

	@FindBy(xpath = "//button/span[text()=\"Add\"]/../following-sibling::button")
	private WebElement addDropdown;

	@FindBy(xpath = "//ul/li//span[text()=\"OPSSI - Surgical Site Infection\"]")
	private WebElement firstOptionInAddDropdown;

	// default values
	public String page_name = "Event List";
	public String navigation_page_name = "Event";

	public EventsPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	public void addEvent() throws InterruptedException, IOException {
		try {
			if (addDropdown.isDisplayed()) {
				addDropdown.click();
				super.Sleep(2);
				firstOptionInAddDropdown.click();
				super.Sleep(10);
				ExtentManager.ExecuteTest("Verify Add Events button click", true, "", driver, "Add Event Button");
			}
		} catch (Exception e) {
			ExtentManager.ExecuteTest("Verify Add Events button click", false, e.toString(), driver,
					"Add Event Button");
		}
	}

	public void fillAddEventsFirstPage(String facilityId, String patientId, String lname, String fname, String mname)
			throws IOException {
		try {
//		super.fillInputBoxInTableByLabel("Facility ID", facilityId);
			super.fillInputBoxInTableByLabel("Patient ID", patientId);
			super.fillInputBoxInTableByLabel("Last Name", lname);
			super.fillInputBoxInTableByLabel("First Name", fname);
			super.fillInputBoxInTableByLabel("Middle Name", mname);
			super.webElementClick("Next Button", nextButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddEventsSecondPage");
		}
	}

	public void fillAddEventsSecondPage(String ssn, String secondaryId, String medicare, String dob) {
		try {
			super.fillInputBoxInTableByLabel("Social Security #", ssn);
			super.fillInputBoxInTableByLabel("Secondary ID", secondaryId);
			super.fillInputBoxInTableByLabel("Medicare #", medicare);
			super.openDropdownAndSelectRandomOptionInDropdown("Gender");
			super.selectTodaysDateInCalendar();
			super.webElementClick("Next Button", nextButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddEventsSecondPage");
		}
	}

	public void fillAddEventsThirdPage() {
		try {
			super.openDropdownAndSelectRandomOptionInDropdown("Event Type");
			super.selectTodaysDateInCalendar(1);
			super.openDropdownAndSelectRandomOptionInDropdown("NHSN Procedure Code");
			super.selectTodaysDateInCalendar(2);
			super.openDropdownAndSelectRandomOptionInDropdown("Location");
			super.selectTodaysDateInCalendar(3);
			super.webElementClick("Next Button", nextButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddEventsThirdPage");
		}
	}

	public void fillAddEventsFourthPage() {
		try {
			super.openDropdownAndSelectRandomOptionInDropdown("SSI Level");
			this.selectSignsAndSymptoms();
			this.selectLaboratory();
			super.openDropdownAndSelectRandomOptionInDropdown("SSI Event Detected");
			super.openDropdownAndSelectRandomOptionInDropdown("Died");
			super.webElementClick("Next Button", nextButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddEventsFourthPage");
		}
	}

	public void fillAddEventsFifthPage() {
		try {
			super.openDropdownAndSelectRandomOptionInDropdown("Pathogens Identified");
			super.webElementClick("Submit Button", submitButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddEventsFifthPage");
		}
	}

	public void fillSearchFields(String eventNo, String eventType, String eventDate, String lName, String fName,
			String patientId, String location, String completionStatus, String linkedEvents) {
		try {
			super.fillInputBoxInTableByTableHeader("Event #", eventNo);
			super.clickByXpath("//tr/th[2]//button[@aria-label=\"select\"]");
			super.clickByXpath(String.format("//ul/li/span[text()=\"%s\"]", eventType));
			super.fillInputBoxInTableByTableHeader("Event Date", eventDate);
			super.fillInputBoxInTableByTableHeader("Last Name", lName);
			super.fillInputBoxInTableByTableHeader("First Name", fName);
			super.fillInputBoxInTableByTableHeader("Patient ID", patientId);
			super.fillInputBoxInTableByTableHeader("Location", location);
			super.fillInputBoxInTableByTableHeader("Completion Status", completionStatus);
			super.fillInputBoxInTableByTableHeader("Linked Events", linkedEvents);
		} catch (Exception e) {
			System.out.println("Error occured fillSearchFields");
		}
	}

	// verifies the search result in the table
	public Pair<Boolean, String> verifySearchResult(String eventNo, String eventType, String eventDate, String lName,
			String fName, String patientId, String location, String completionStatus, String linkedEvents) {
		try {
			ArrayList<Boolean> validation = new ArrayList<Boolean>();
			if (eventNo.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Event #", eventNo));
			}
//    		if(eventType.isEmpty()) {
//    			validation.add(true);
//    		} else {
//    			validation.add(super.verifySearchResultByTableHeader("Event Type", eventType));
//    		}
			if (eventDate.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Event Date", eventDate));
			}
			if (patientId.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Patient ID", patientId));
			}
			if (location.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Location", location));
			}
			if (completionStatus.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Completion Status", completionStatus));
			}
			if (linkedEvents.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Linked Events", linkedEvents));
			}
			if (lName.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Last Name", lName));
			}
			if (fName.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("First Name", fName));
			}

			Boolean flag = true;
			for (boolean value : validation) {
				if (value == false) {
					flag = false;
					break;
				}
			}
			if (flag == true) {
				return Pair.of(true, "");
			} else {
				return Pair.of(false, "The search result did not match with the provided input.");
			}
		} catch (Exception e) {
			return Pair.of(false, e.toString());
		}
	}

	public void selectSignsAndSymptoms() throws InterruptedException, IOException {
		String verification_string = "Select<b> Signs and Symptoms </b>";
		try {
			List<WebElement> elements = driver.findElements(By.xpath(
					"//label[text()=\"Signs & Symptoms (check all that apply)\"]/following-sibling::div//input[@type=\"checkbox\"]"));
			for (int i = 1; i <= elements.size(); i++) {
				super.selectRandomOptionInCheckbox(
						"(//label[text()=\"Signs & Symptoms (check all that apply)\"]/following-sibling::div//input[@type=\"checkbox\"])["
								+ i + "]");
			}
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

	public void selectLaboratory() throws InterruptedException, IOException {
		String verification_string = "Select<b> Laboratory </b>";
		try {
			List<WebElement> elements = driver.findElements(
					By.xpath("//label[text()=\"Laboratory\"]/following-sibling::div//input[@type=\"checkbox\"]"));
			for (int i = 1; i <= elements.size(); i++) {
				super.selectRandomOptionInCheckbox(
						"(//label[text()=\"Laboratory\"]/following-sibling::div//input[@type=\"checkbox\"])[" + i
								+ "]");
			}
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

}