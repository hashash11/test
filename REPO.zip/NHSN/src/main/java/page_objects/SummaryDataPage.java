package page_objects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SummaryDataPage extends BasePage {

	@FindBy(xpath = "//form")
	private WebElement addPatientForm;

	@FindBy(xpath = "//button/span[text()=\"Next\"]")
	private WebElement nextButton;

	// default values
	public String page_name = "Summary Data";

	public SummaryDataPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	public void fillAddSummaryDataPage(String months) throws InterruptedException {
		try {
			super.openDropdownAndSelectRandomOptionInDropdown("Summary Month");
			super.openDropdownAndSelectRandomOptionInDropdown("Summary Year");
			super.fillInputBoxInTableByLabel("Total number of encounters (admissions) for the month:", months);
			super.clickByXpath("//input[@id=\"opSummary.noEventSDOM\"]");
		} catch (Exception e) {
			System.out.println("Error occured fillAddSummaryDataPage");
		}
	}
}
