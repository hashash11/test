package page_objects;

import org.apache.commons.lang3.tuple.Pair;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import manager_objects.ExtentManager;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PatientPage extends BasePage {

	@FindBy(xpath = "//button/span[text()=\"Next\"]")
	private WebElement nextButton;

	@FindBy(xpath = "//button/span[text()=\"Next\"]")
	private WebElement secondNextButton;

	@FindBy(xpath = "//span[text()=\"3\"]")
	private WebElement thirdStep;

	@FindBy(xpath = "//button/span[text()=\"Submit\"]")
	private WebElement submitButton;

	@FindBy(xpath = "//label[text()=\"Gender\"]/following-sibling::div//button[@aria-label=\"select\"]")
	private WebElement genderDropdown;

	@FindBy(xpath = "//label[text()=\"Ethnicity\"]/following-sibling::div//button[@aria-label=\"select\"]")
	private WebElement ethnicityDropdown;

	// default values
	public String page_name = "Patients";

	public PatientPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	// fills the search input boxes in Patients
	// Pass the facility id, patient id, last name, first name, ssn, gender, dob and
	// secondary id as parameter
	public void fillSearchFields(String facilityId, String patientId, String lName, String fName, String ssn,
			String gender, String dob, String secondaryId) {
		try {
			super.fillInputBoxInTableByTableHeader("Facility ID", facilityId);
			super.fillInputBoxInTableByTableHeader("Patient ID", patientId);
			super.fillInputBoxInTableByTableHeader("Last Name", lName);
			super.fillInputBoxInTableByTableHeader("First Name", fName);
			super.fillInputBoxInTableByTableHeader("Social Security #", ssn);
			super.fillInputBoxInTableByTableHeader("Gender", gender);
			super.fillInputBoxInTableByTableHeader("Date of Birth", dob);
			super.fillInputBoxInTableByTableHeader("Secondary ID", secondaryId);
		} catch (Exception e) {
			System.out.println("Error occured fillSearchFields");
		}
	}

	// verifies the search result in the table
	// Pass the facility id, patient id, last name, first name, ssn, gender, dob and
	// secondary id as parameter
	public Pair<Boolean, String> verifySearchResult(String facilityId, String patientId, String lName, String fName,
			String ssn, String gender, String dob, String secondaryId) {
		try {
			ArrayList<Boolean> validation = new ArrayList<Boolean>();
			if (facilityId.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Facility ID", facilityId));
			}
			if (patientId.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Patient ID", patientId));
			}
			if (lName.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Last Name", lName));
			}
			if (fName.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("First Name", fName));
			}
			if (ssn.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Social Security #", ssn));
			}
			if (gender.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Gender", gender));
			}
			if (dob.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Date of Birth", dob));
			}
			if (secondaryId.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Secondary ID", secondaryId));
			}

			Boolean flag = true;
			for (boolean value : validation) {
				if (value == false) {
					flag = false;
					break;
				}
			}
			if (flag == true) {
				return Pair.of(true, "");
			} else {
				return Pair.of(false, "The search result did not match with the provided input.");
			}
		} catch (Exception e) {
			return Pair.of(false, e.toString());
		}
	}

	public void fillAddPatientFirstPage(String facilityId, String patientId, String lname, String fname, String mname) {
		try {
			// super.fillInputBoxInTableByLabel("Facility ID", facilityId);
			super.fillInputBoxInTableByLabel("Patient ID", patientId);
			super.fillInputBoxInTableByLabel("Last Name", lname);
			super.fillInputBoxInTableByLabel("First Name", fname);
			super.fillInputBoxInTableByLabel("Middle Name", mname);
			super.webElementClick("Next Button", nextButton);
		} catch (Exception e) {
			System.out.println("Error occured fillAddPatientFirstPage");
		}
	}

	public void fillAddPatientSecondPage(String ssn, String secondaryId, String medicare, String dob) {
		try {
			super.Sleep();
			super.fillInputBoxInTableByLabel("Social Security #", ssn);
			super.Sleep();
			super.fillInputBoxInTableByLabel("Secondary ID", secondaryId);
			super.Sleep();
			super.fillInputBoxInTableByLabel("Medicare #", medicare);
			super.Sleep();
			super.selectTodaysDateInCalendar();
			super.Sleep();
//		super.updateDate("Date of Birth", dob);
//		super.Sleep();
			super.openDropdownAndSelectRandomOptionInDropdown("Gender");
			super.openDropdownAndSelectRandomOptionInDropdown("Ethnicity");
			this.selectRace();
			super.Sleep(60);
//		thirdStep.click();
		} catch (Exception e) {
			System.out.println("Error occured fillAddPatientSecondPage");
		}
	}

	public void fillAddPatientThirdPage(String comments) {
		try {
			this.scrollIntoViewAndClickNext();
			super.Sleep();
			super.fillTextareaByLabel("Comments", comments);
			super.webElementClick("Submit Button", submitButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddPatientThirdPage");
		}
	}

	public void scrollIntoViewAndClickNext() throws IOException {
		String verification_string = "Scroll <b> Next Button </b> into view and click";
		try {
			JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			jsExecutor.executeScript("arguments[0].scrollIntoView(true);", nextButton);
			jsExecutor.executeScript("arguments[0].click();", nextButton);
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

	public void selectRace() throws IOException {
		String verification_string = "Select <b> race </b>";
		try {
			List<WebElement> elements = driver
					.findElements(By.xpath("//div[text()=\"Race\"]/following-sibling::div//input[@type=\"checkbox\"]"));
			for (int i = 1; i <= 1; i++) {
				super.selectRandomOptionInCheckbox(
						"(//div[text()=\"Race\"]/following-sibling::div//input[@type=\"checkbox\"])[" + i + "]");
			}
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

}
