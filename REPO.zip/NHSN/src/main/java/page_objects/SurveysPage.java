package page_objects;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.tuple.Pair;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import manager_objects.ExtentManager;

public class SurveysPage extends BasePage {

	@FindBy(xpath = "//form")
	private WebElement addPatientForm;

	@FindBy(xpath = "//button/span[text()=\"Next\"]")
	private WebElement nextButton;

	@FindBy(xpath = "//button/span[text()=\"Submit\"]")
	private WebElement submitButton;

	// default values
	public String page_name = "Surveys";

	public SurveysPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	public void fillAddSurveysFirstPage() {
		try {
			super.openDropdownAndSelectRandomOptionInDropdown("Facility ID:");
			super.openDropdownAndSelectRandomOptionInDropdown("Survey Type:");
			super.openDropdownAndSelectRandomOptionInDropdown("Survey Year:");
			super.webElementClick("Next Button", nextButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddSurveysFirstPage");
		}
	}

	public void fillAddSurveysSecondPage(String operating_room_count, String procedure_room_count,
			String patient_admission_count) {
		try {
			this.selectOwnership();
			super.openDropdownAndSelectRandomOptionInDropdown("2. Specialty (select one):");
			this.selectSpecialities();
			super.fillInputBoxInTableByLabel("4. Total number of operating rooms at time of survey completion:",
					operating_room_count);
			super.fillInputBoxInTableByLabel("5. Total number of procedure rooms at time of survey completion:",
					procedure_room_count);
			super.fillInputBoxInTableByLabel("6. Total number of patient admissions in this survey year:",
					patient_admission_count);
			super.openDropdownAndSelectRandomOptionInDropdown(
					"7. Accredited by a CMS-approved accrediting organization:");
			super.webElementClick("Submit Button", submitButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddSurveysSecondPage");
		}
	}

	public void selectOwnership() throws InterruptedException, IOException {
		String verification_string = "Select <b>Ownership</b>.";
		try {
			List<WebElement> elements = driver.findElements(By.xpath(
					"//div[text()=\"1. Ownership (Check all that apply):\"]/following-sibling::div//input[@type=\"checkbox\"]"));
			for (int i = 1; i <= elements.size(); i++) {
				super.selectRandomOptionInCheckbox(
						"(//div[text()=\"1. Ownership (Check all that apply):\"]/following-sibling::div//input[@type=\"checkbox\"])["
								+ i + "]");
			}
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

	public void selectSpecialities() throws InterruptedException, IOException {
		String verification_string = "Select <b>Specialities</b>.";
		try {
			List<WebElement> elements = driver.findElements(By.xpath(
					"//div[text()=\"3. Check all the specialty(ies) currently performed in your facility:\"]/following-sibling::div//input[@type=\"checkbox\"]"));
			for (int i = 1; i <= elements.size(); i++) {
				super.selectRandomOptionInCheckbox(
						"(//div[text()=\"3. Check all the specialty(ies) currently performed in your facility:\"]/following-sibling::div//input[@type=\"checkbox\"])["
								+ i + "]");
			}
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

	public void fillSearchFields(String facilityID, String facilityName, String surveyYear, String surveyType) {
		try {
			super.fillInputBoxInTableByTableHeader("Facility ID", facilityID);
			super.fillInputBoxInTableByTableHeader("Facility Name", facilityName);
			super.fillInputBoxInTableByTableHeader("Survey Year", surveyYear);
			super.fillInputBoxInTableByTableHeader("Survey Type", surveyType);
		} catch (Exception e) {
			System.out.println("Error occured fillSearchFields");
		}
	}

	// verifies the search result in the table
	public Pair<Boolean, String> verifySearchResult(String facilityID, String facilityName, String surveyYear,
			String surveyType) {
		try {
			ArrayList<Boolean> validation = new ArrayList<Boolean>();
			if (facilityID.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Facility ID", facilityID));
			}
			if (facilityName.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Facility Name", facilityName));
			}
			if (surveyYear.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Survey Year", surveyYear));
			}
			if (surveyType.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Survey Type", surveyType));
			}

			Boolean flag = true;
			for (boolean value : validation) {
				if (value == false) {
					flag = false;
					break;
				}
			}
			if (flag == true) {
				return Pair.of(true, "");
			} else {
				return Pair.of(false, "The search result did not match with the provided input.");
			}
		} catch (Exception e) {
			return Pair.of(false, e.toString());
		}
	}
}
