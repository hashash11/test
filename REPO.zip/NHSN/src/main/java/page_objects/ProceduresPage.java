package page_objects;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.tuple.Pair;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import manager_objects.ExtentManager;

public class ProceduresPage extends BasePage {

	@FindBy(xpath = "//form")
	private WebElement addPatientForm;

	@FindBy(xpath = "//button/span[text()=\"Next\"]")
	private WebElement nextButton;

	@FindBy(xpath = "//button/span[text()=\"Submit\"]")
	private WebElement submitButton;

	// default values
	public String page_name = "Procedure List";
	public String navigation_page_name = "Procedure";

	public ProceduresPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	public void fillSearchFields(String procedureNo, String procedureCode, String cptCode, String procedureDate,
			String lName, String fName, String patientId, String completionStatus, String linkedEvents) {
		try {
			super.fillInputBoxInTableByTableHeader("Procedure #", procedureNo);
			super.clickByXpath("//tr/th[2]//button[@aria-label=\"select\"]");
			super.clickByXpath(String.format("//ul/li/span[text()=\"%s\"]", procedureCode));
			super.fillInputBoxInTableByTableHeader("CPT Code", cptCode);
			super.fillInputBoxInTableByTableHeader("Procedure Date", procedureDate);
			super.fillInputBoxInTableByTableHeader("Last Name", lName);
			super.fillInputBoxInTableByTableHeader("First Name", fName);
			super.fillInputBoxInTableByTableHeader("Patient ID", patientId);
			super.fillInputBoxInTableByTableHeader("Completion Status", completionStatus);
			super.fillInputBoxInTableByTableHeader("Linked Events", linkedEvents);
		} catch (Exception e) {
			System.out.println("Error occured fillSearchFields");
		}
	}

	// verifies the search result in the table
	public Pair<Boolean, String> verifySearchResult(String procedureNo, String procedureCode, String cptCode,
			String procedureDate, String lName, String fName, String patientId, String completionStatus,
			String linkedEvents) {
		try {
			ArrayList<Boolean> validation = new ArrayList<Boolean>();
			if (procedureNo.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Procedure #", procedureNo));
			}
//    		if(procedureCode.isEmpty()) {
//    			validation.add(true);
//    		} else {
//    			validation.add(super.verifySearchResultByTableHeader("Procedure Code", procedureCode));
//    		}
			if (cptCode.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("CPT Code", cptCode));
			}
			if (procedureDate.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Procedure Date", procedureDate));
			}
			if (lName.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Last Name", lName));
			}
			if (fName.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("First Name", fName));
			}
			if (patientId.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Patient ID", patientId));
			}
			if (completionStatus.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Completion Status", completionStatus));
			}
			if (linkedEvents.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Linked Events", linkedEvents));
			}

			Boolean flag = true;
			for (boolean value : validation) {
				if (value == false) {
					flag = false;
					break;
				}
			}
			if (flag == true) {
				return Pair.of(true, "");
			} else {
				return Pair.of(false, "The search result did not match with the provided input.");
			}
		} catch (Exception e) {
			return Pair.of(false, e.toString());
		}
	}

	public void fillAddProceduresFirstPage(String facilityId, String patientId, String lname, String fname,
			String mname) {
		try {
//		super.fillInputBoxInTableByLabel("Facility ID", facilityId);
			super.fillInputBoxInTableByLabel("Patient ID", patientId);
			super.fillInputBoxInTableByLabel("Last Name", lname);
			super.fillInputBoxInTableByLabel("First Name", fname);
			super.fillInputBoxInTableByLabel("Middle Name", mname);
			super.webElementClick("Next Button", nextButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddProceduresFirstPage");
		}
	}

	public void fillAddProceduresSecondPage(String ssn, String secondaryId, String medicare, String dob) {
		try {
			super.fillInputBoxInTableByLabel("Social Security #", ssn);
			super.fillInputBoxInTableByLabel("Secondary ID", secondaryId);
			super.fillInputBoxInTableByLabel("Medicare #", medicare);
			super.selectTodaysDateInCalendar();
			super.openDropdownAndSelectRandomOptionInDropdown("Gender");
			super.openDropdownAndSelectRandomOptionInDropdown("Ethnicity");
//		this.selectRace();
//		super.Sleep();
			super.webElementClick("Next Button", nextButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddProceduresSecondPage");
		}
	}

	public void fillAddProceduresThirdPage() {
		try {
			super.openDropdownAndSelectRandomOptionInDropdown("NHSN Procedure Code");
			super.openDropdownAndSelectRandomOptionInDropdown("CPT Code");
			super.selectTodaysDateInCalendar();
			super.webElementClick("Next Button", nextButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddProceduresThirdPage");
		}
	}

	public void fillAddProceduresFourthPage(String hours, String mins, String height, String weight) {
		try {
			super.fillInputBoxInTableByLabel("Duration (Hrs)", hours);
			super.fillInputBoxInTableByLabel("Duration (Mins)", mins);
			super.fillInputBoxInTableByLabel("Height", height);
			super.fillInputBoxInTableByLabel("Weight", weight);
			super.openDropdownAndSelectRandomOptionInDropdown("Wound Class");
			super.openDropdownAndSelectRandomOptionInDropdown("ASA Score");
			super.openDropdownAndSelectRandomOptionInDropdown("Scope");
			super.openDropdownAndSelectRandomOptionInDropdown("Diabetes Mellitus");
			super.openDropdownAndSelectRandomOptionInDropdown("Surgeon Code");
			super.webElementClick("Next Button", nextButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddProceduresFourthPage");
		}
	}

	public void fillAddProcedureFifthPage(String comments) {
		try {
			super.fillTextareaByLabel("Comments", comments);
			super.webElementClick("Submit Button", submitButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddProcedureFifthPage");
		}
	}

	public void selectRace() throws InterruptedException, IOException {
		String verification_string = "Select <b> race </b>";
		try {
			List<WebElement> elements = driver
					.findElements(By.xpath("//div[text()=\"Race\"]/following-sibling::div//input[@type=\"checkbox\"]"));
			for (int i = 1; i <= elements.size(); i++) {
				super.selectRandomOptionInCheckbox(
						"(//div[text()=\"Race\"]/following-sibling::div//input[@type=\"checkbox\"])[" + i + "]");
			}
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

}
