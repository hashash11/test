package page_objects;

import java.util.ArrayList;

import org.apache.commons.lang3.tuple.Pair;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UsersPage extends BasePage {

	@FindBy(xpath = "//form")
	private WebElement addPatientForm;

	@FindBy(xpath = "//button/span[text()=\"Next\"]")
	private WebElement nextButton;

	@FindBy(xpath = "//button/span[text()=\"Submit\"]")
	private WebElement submitButton;

	// default values
	public String page_name = "Users";

	public UsersPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	public void fillAddUserFirstPage(String user_id, String email, String prefix, String first_name, String middle_name,
			String last_name, String title) {
		try {
			super.fillInputBoxInTableByLabel("User ID:", user_id);
			super.fillInputBoxInTableByLabel("E-mail Address:", email);
			super.fillInputBoxInTableByLabel("Prefix:", prefix);
			super.fillInputBoxInTableByLabel("First Name:", first_name);
			super.fillInputBoxInTableByLabel("Middle Name:", middle_name);
			super.fillInputBoxInTableByLabel("Last Name:", last_name);
			super.fillInputBoxInTableByLabel("Title:", title);
			super.openDropdownAndSelectRandomOptionInDropdown("User Active:");
			super.openDropdownAndSelectRandomOptionInDropdown("User Type:");
			super.webElementClick("Next Button", nextButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddUserFirstPage");
		}
	}

	public void fillAddUserSecondPage(String password) {
		try {
			super.fillInputBoxInTableByLabel("Enter New Password for user:", password);
			super.fillInputBoxInTableByLabel("Re-enter New Password for user:", password);
			super.webElementClick("Next Button", nextButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddUserSecondPage");
		}
	}

	public void fillAddUserThirdPage(String address_1, String address_2, String address_3, String city, String zipcode,
			String zipcode_ext) {
		try {
			super.fillInputBoxInTableByLabel("Address, line 1:", address_1);
			super.fillInputBoxInTableByLabel("Address, line 2:", address_2);
			super.fillInputBoxInTableByLabel("Address, line 3:", address_3);
			super.fillInputBoxInTableByLabel("City:", city);
			super.openDropdownAndSelectRandomOptionInDropdown("State:");
			super.openDropdownAndSelectRandomOptionInDropdown("County:");
			super.fillInputBoxInTableByLabel("Zip Code:", zipcode);
			super.fillInputBoxInTableByLabel("Zip Code Ext:", zipcode_ext);
			super.webElementClick("Next Button", nextButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddUserThirdPage");
		}
	}

	public void fillAddUserFourthPage(String phone_number, String extension, String fax_number,
			String home_phone_number, String home_extension, String beeper) {
		try {
			super.fillInputBoxInTableByLabel("Phone Number:", phone_number);
			super.fillInputBoxInTableByLabel("Extension:", extension);
			super.fillInputBoxInTableByLabel("Fax Number:", fax_number);
			super.fillInputBoxInTableByLabel("Home Phone Number:", home_phone_number);
			super.fillInputBoxInTableByLabel("Home Extension:", home_extension);
			super.fillInputBoxInTableByLabel("Beeper:", beeper);
			super.webElementClick("Submit Button", submitButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddUserFourthPage");
		}
	}

	public void fillSearchFields(String search_name, String search_title, String search_user_id, String search_email,
			String search_user_type, String search_active) {
		try {
			super.fillInputBoxInTableByTableHeader("Name", search_name);
			super.fillInputBoxInTableByTableHeader("Title", search_title);
			super.fillInputBoxInTableByTableHeader("User ID", search_user_id);
			super.fillInputBoxInTableByTableHeader("E-mail", search_email);
			super.fillInputBoxInTableByTableHeader("User Type", search_user_type);
			super.fillInputBoxInTableByTableHeader("Active", search_active);
		} catch (Exception e) {
			System.out.println("Error occured fillSearchFields");
		}
	}

	// verifies the search result in the table
	public Pair<Boolean,String> verifySearchResult(String search_name, String search_title, String search_user_id,
			String search_email, String search_user_type, String search_active) {
		try {
			ArrayList<Boolean> validation = new ArrayList<Boolean>();
			if (search_name.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Name", search_name));
			}
			if (search_title.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Title", search_title));
			}
			if (search_user_id.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("User ID", search_user_id));
			}
			if (search_email.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("E-mail", search_email));
			}
			if (search_user_type.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("User Type", search_user_type));
			}
			if (search_active.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Active", search_active));
			}

			Boolean flag = true;
			for (boolean value : validation) {
				if (value == false) {
					flag = false;
					break;
				}
			}
			if (flag == true) {
				return Pair.of(true, "");
			} else {
				return Pair.of(false, "The search result did not match with the provided input.");
			}
		} catch (Exception e) {
			return Pair.of(false, e.toString());
		}
	}
}
