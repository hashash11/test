package page_objects;

import org.apache.commons.lang3.tuple.Pair;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class AlertsPage extends BasePage {

	// default values
	public String page_name = "Alerts";

	public AlertsPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	public Pair<Boolean, String> all_cards_visible() {
		Pair<Boolean, String> flag = Pair.of(true, "");
		for (int i = 1; i <= 6; i++) {
			WebElement element = driver.findElement(By.xpath("(//div[@class=\"action-item-card\"])[" + i + "]"));
			if (element.isDisplayed()) {
			} else {
				flag = Pair.of(false, "");;
				break;
			}
		}
		return flag;
	}

}
