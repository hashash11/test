package page_objects;

import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Random;

import org.apache.commons.lang3.tuple.Pair;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import manager_objects.ExtentManager;

public abstract class BasePage {
	protected WebDriver driver;

	private SoftAssert softAssert = new SoftAssert();

	@FindBy(xpath = "//title")
	private WebElement pageTitle;

	@FindBy(xpath = "//button/span[text()=\"Add\"]")
	private WebElement addButton;

	@FindBy(xpath = "//form")
	private WebElement addPatientForm;

	@FindBy(xpath = "//button//span[text()=\"TODAY\"]")
	private WebElement todayDate;

	@FindBy(xpath = "//button[@title=\"Toggle calendar\"]")
	private WebElement toggleCalendarButton;

	public BasePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// Common methods to interact with web elements can be defined here.
	public void Sleep() throws InterruptedException {
		Thread.sleep(2000);
	}

	// Common methods to interact with web elements can be defined here.
	public void Sleep(int seconds) throws InterruptedException {
		int miliseconds = seconds * 1000;
		Thread.sleep(miliseconds);
	}

	// implicitly wait function on Webdriver
	public void implicitlyWait(int seconds) {
		// Thread.sleep(2000);

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(seconds));
	}

	// implicitly wait function on Webdriver
	public void implicitlyWait() {
		// Thread.sleep(2000);

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}

	// Common method to click element based on the passed Xpath
	public void clickByXpath(String target_xpath) throws IOException {
		String verification_string = "Click by Xpath: <b>" + target_xpath + " </b>";
		try {
			driver.findElement(By.xpath(target_xpath)).click();
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

	// Common method to click element using Javascript executor (in case the element
	// becomes not interactable) based on Xpath
	public void clickByXpath(String target_xpath, boolean javasript_executor) {
		if (javasript_executor == true) {
			JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			WebElement element = this.returnElementFromXpath(target_xpath);
			jsExecutor.executeScript("arguments[0].click();", element);
		} else {
			driver.findElement(By.xpath(target_xpath)).click();
		}
	}

	// Input text in text box.
	// Pass the Input field Xpath and the value you want to input as parameters
	public void inputTextFieldByXpath(String target_xpath, String input_value) {
		driver.findElement(By.xpath(target_xpath)).sendKeys(input_value);
	}

	// Clears the input field.
	// Pass the input field Xpath as parameter
	public void clearInputField(String target_xpath) {
		driver.findElement(By.xpath(target_xpath)).clear();
	}

	// Verifies Page Title.
	// Pass the expected title as parameter.
	// Returns true if title matches.
	public Pair<Boolean, String> verifyPageTitle(String expected_title) {
		try {
			String actual_title = pageTitle.getAttribute("innerHTML").toString();
			this.Sleep(10);
			if (actual_title.contains(expected_title)) {
				return Pair.of(true, "");
			}
			return Pair.of(false, "<b>" + expected_title + "</b> did not match with Page Title");
		} catch (Exception e) {
			return Pair.of(false, "<b>" + expected_title + "</b> did not match with Page Title<br>" + e.toString());
		}
	}

	public void selectMenu(String menu) throws IOException {
		String verification_string = "Select <b>" + menu + "</b> Menu Item";
		try {
			this.clickByXpath(String.format("//ul/li/span[text()=\"%s\"]", menu));
			this.Sleep();
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

	public void selectMenu(String menu, String sub_menu) throws InterruptedException, IOException {
		String verification_string = "Select <b>" + sub_menu + "</b> Sub Menu Item under <b>" + menu + "</b> Menu Item";
		try {
			this.clickByXpath(String.format("//ul/li/span[text()=\"%s\"]", menu));
			this.implicitlyWait();
			this.clickByXpath(String.format("//ul/li/span[text()=\"%s\"]", sub_menu));
			this.implicitlyWait();
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

	public Boolean verifyPage(String menu) {
		try {
			return driver
					.findElement(By.xpath(
							String.format("//div[@class=\"page-content-header\" and contains(text(), \"%s\")]", menu)))
					.isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}

	// This type of assertion will continue the execution but log the error in
	// extent report
	public Pair<Boolean, String> verifyPageWithSoftAssertion(String expected_page_title) {
		try {
			String actual_page_title = driver.findElement(By.xpath("//div[@class=\"page-content-header\"]")).getText();
			softAssert.assertTrue(actual_page_title.contains(expected_page_title),
					"The actual page title does not contain the expected page title.");
			try {
				softAssert.assertAll(); // This will throw an error if any of the assertions fail
				return Pair.of(true, "");
			} catch (AssertionError e) {
				return Pair.of(false, e.toString());
			}
		} catch (Exception e) {
			return Pair.of(false, e.toString());
		}
	}

	// This type of assertion will stop the execution and throw an error
	public Boolean verifyPageWithAssertion(String expected_page_title) {
		try {
			String actual_page_title = driver.findElement(By.xpath("//div[@class=\"page-content-header\"]")).getText();
			Assert.assertTrue(actual_page_title.contains(expected_page_title),
					"The actual page title does not contain the expected page title.");
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public void clickAdd() {
		try {
			if (addButton.isDisplayed()) {
				addButton.click();
			}
			this.Sleep(11);
		} catch (Exception e) {
			System.out.println("Error occured clickAdd");
		}
	}

	public void fillInputBoxInTableByTableHeader(String header, String inputText)
			throws InterruptedException, IOException {
		String verification_string = "Fill Input box under header <b>" + header + " </b> with text <b>" + inputText
				+ "</b>";
		try {
			int headerIndex = Integer
					.parseInt(driver.findElement(By.xpath(String.format("//*[text()=\"%s\"]/ancestor::th", header)))
							.getAttribute("cellIndex"))
					+ 1;
			WebElement inputBox = driver.findElement(By.xpath(String.format("//tr/th[%s]//input", headerIndex)));
			inputBox.clear();
			inputBox.sendKeys(inputText);
			this.Sleep(2);
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

	public Boolean verifySearchResultByTableHeader(String header, String expected_string) {
		int headerIndex = Integer
				.parseInt(driver.findElement(By.xpath(String.format("//span[text()=\"%s\"]/ancestor::th", header)))
						.getAttribute("cellIndex"))
				+ 1;
		WebElement tableRow;
		try {
			tableRow = driver.findElement(
					By.xpath(String.format("//tr[1]//td[%d][text()=\"%s\"]", headerIndex, expected_string)));
		} catch (Exception e) {
			try {
				tableRow = driver.findElement(
						By.xpath(String.format("//tr[%d]/td//span[text()=\"%s\"]", headerIndex, expected_string)));
			} catch (Exception ex) {
				return false;
			}
		}
		return tableRow.isDisplayed();
	}

	public void fillInputBoxInTableByLabel(String label, String inputText) throws InterruptedException, IOException {
		String verification_string = "Fill <b>" + label + " </b> input box with <b>" + inputText + "</b>";
		try {
			WebElement inputBox = driver
					.findElement(By.xpath(String.format("//*[text()=\"%s\"]/following-sibling::*//input", label)));
			inputBox.click();
			inputBox.clear();
			this.Sleep(2);
			inputBox.sendKeys(inputText);
			this.Sleep(2);
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			try {
				WebElement inputBox = driver
						.findElement(By.xpath(String.format("//*[text()=\"%s\"]/preceding-sibling::*//input", label)));
				inputBox.click();
				inputBox.clear();
				inputBox.sendKeys(inputText);
				this.Sleep(2);
				ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
			} catch (Exception ex) {
				try {
					WebElement inputBox = driver.findElement(
							By.xpath(String.format("//*[text()=\"%s\"]/following-sibling::input[1]", label)));
					inputBox.click();
					inputBox.clear();
					inputBox.sendKeys(inputText);
					this.Sleep(2);
					ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
				} catch (Exception exc) {
					ExtentManager.ExecuteTest(verification_string, false,
							e.toString() + "<br><br>" + ex.toString() + "<br><br>" + exc.toString(), driver,
							verification_string);
				}
			}
		}
	}

	public void webElementClick(String element_name, WebElement element) throws IOException {
		String verification_string = "Click <b>" + element_name + "</b>";
		try {
			element.click();
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

	public void updateValueByLabel(String label, String inputText) throws InterruptedException, IOException {
		String verification_string = "Update <b>" + label + " </b> input box with <b>" + inputText + "</b>";
		try {
			WebElement inputBox = driver
					.findElement(By.xpath(String.format("//label[text()=\"%s\"]/preceding-sibling::*//input", label)));
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value', arguments[1]);", inputBox, inputText);
			;
			this.Sleep(2);
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			try {
				WebElement inputBox = driver.findElement(
						By.xpath(String.format("//label[text()=\"%s\"]/following-sibling::*//input", label)));
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].setAttribute('value', arguments[1]);", inputBox, inputText);
				;
				this.Sleep(2);
				ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
			} catch (Exception ex) {
				try {
					WebElement inputBox = driver.findElement(
							By.xpath(String.format("//label[text()=\"%s\"]/following-sibling::input[1]", label)));
					JavascriptExecutor js = (JavascriptExecutor) driver;
					js.executeScript("arguments[0].setAttribute('value', arguments[1]);", inputBox, inputText);
					;
					this.Sleep(2);
					ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
				} catch (Exception exc) {
					ExtentManager.ExecuteTest(verification_string, false,
							e.toString() + "<br><br>" + ex.toString() + "<br><br>" + exc.toString(), driver,
							verification_string);
				}
			}
		}
	}

	public void updateDate(String label, String inputText) throws InterruptedException {
		try {
			WebElement dateBox = driver
					.findElement(By.xpath(String.format("//label[text()=\"%s\"]/following-sibling::*//input", label)));
			Actions actions = new Actions(driver);
			actions.doubleClick(dateBox).perform();
			actions.sendKeys("11");
			this.Sleep();
			actions.sendKeys(org.openqa.selenium.Keys.ARROW_RIGHT).perform();
			actions.sendKeys(org.openqa.selenium.Keys.ARROW_RIGHT).perform();
			actions.sendKeys("11");
			this.Sleep();
			actions.doubleClick(dateBox).perform();
			actions.sendKeys(org.openqa.selenium.Keys.ARROW_RIGHT).perform();
			actions.sendKeys(org.openqa.selenium.Keys.ARROW_RIGHT).perform();
			this.Sleep();
			actions.sendKeys("1994");
			this.Sleep();
		} catch (Exception e) {

		}
	}

	public void fillTextareaByLabel(String label, String inputText) throws InterruptedException, IOException {
		String verification_string = "Fill <b>" + label + " </b> text area with <b>" + inputText + "</b>";
		try {
			WebElement inputBox = driver.findElement(
					By.xpath(String.format("//label[text()=\"%s\"]/preceding-sibling::*//textarea", label)));
			inputBox.clear();
			inputBox.sendKeys(inputText);
			this.Sleep(2);
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			try {
				WebElement inputBox = driver.findElement(
						By.xpath(String.format("//label[text()=\"%s\"]/following-sibling::*//textarea", label)));
				inputBox.clear();
				inputBox.sendKeys(inputText);
				this.Sleep(2);
				ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
			} catch (Exception ex) {
				try {
					WebElement inputBox = driver.findElement(
							By.xpath(String.format("//label[text()=\"%s\"]/following-sibling::textarea[1]", label)));
					inputBox.clear();
					inputBox.sendKeys(inputText);
					this.Sleep(2);
					ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
				} catch (Exception exc) {
					ExtentManager.ExecuteTest(verification_string, false,
							e.toString() + "<br><br>" + ex.toString() + "<br><br>" + exc.toString(), driver,
							verification_string);

				}
			}
		}
	}

	public void openDropdownAndSelectRandomOptionInDropdown(String dropdown_label, String xpath)
			throws InterruptedException, IOException {
		String verification_string = "Select random option in <b>" + dropdown_label + " </b> dropdown with xpath: "
				+ "<b>" + xpath + "</b>";
		try {
			WebElement dropdownIcon = driver.findElement(By.xpath(String.format(
					"//label[text()=\"%s\"]/following-sibling::div//button[@aria-label=\"select\"]", dropdown_label)));
			dropdownIcon.click();
			this.selectRandomOptionInDropdown(xpath);
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

	public void openDropdownAndSelectRandomOptionInDropdown(String dropdown_label)
			throws InterruptedException, IOException {
		String verification_string = "Select random option in <b>" + dropdown_label + " </b> dropdown";
		try {
			WebElement dropdownIcon = driver.findElement(By.xpath(String.format(
					"//label[text()=\"%s\"]/following-sibling::div//button[@aria-label=\"select\"]", dropdown_label)));
			dropdownIcon.click();
			this.Sleep(5);
			this.selectRandomOptionInDropdown("//ul[@role=\"listbox\"]/li");
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			try {
				WebElement dropdownIcon = driver.findElement(By.xpath(
						String.format("//*[@aria-label=\"%s\"]//button[@aria-label=\"select\"]", dropdown_label)));
				dropdownIcon.click();
				this.Sleep(5);
				this.selectRandomOptionInDropdown("//ul[@role=\"listbox\"]/li");
				ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
			} catch (Exception ex) {
				ExtentManager.ExecuteTest(verification_string, false,
						e.toString() + "<br><br>" + ex.toString() + "<br><br>", driver, verification_string);
			}
		}
	}

	public void selectRandomOptionInDropdown(String xpath) throws InterruptedException {
		List<WebElement> elements = driver.findElements(By.xpath(xpath));
		int randomIndex = this.getRandomNumberUsingNextInt(0, elements.size());
		WebElement elementToSelect = elements.get(randomIndex);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", elementToSelect);
		elementToSelect.click();
		this.Sleep(2);
	}

	public void selectRandomOptionInCheckbox(String xpath) {
		int randomIndex = this.getRandomNumberUsingNextInt(0, 10);
		WebElement checkBox = driver.findElement(By.xpath(String.format(xpath)));
		if (randomIndex % 2 == 0) {
			checkBox.click();
		}
	}

	public int getRandomNumberUsingNextInt(int min, int max) {
		Random random = new Random();
		return random.nextInt(max - min) + min;
	}

	public void selectTodaysDateInCalendar() throws InterruptedException, IOException {
		String verification_string = "Select today's date in datepicker";
		try {
			toggleCalendarButton.click();
			this.Sleep(2);
			todayDate.click();
			this.Sleep(2);
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

	public void selectTodaysDateInCalendar(int instance) throws InterruptedException, IOException {
		String verification_string = "Select today's date in datepicker";
		try {
			this.clickByXpath("(//button[@title=\"Toggle calendar\"])[" + instance + "]");
			this.Sleep(2);
			todayDate.click();
			this.Sleep(2);
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

	public void logout() {
		try {
			this.selectMenu("Logout");
		} catch (Exception e) {
			System.out.println("Error occured while logging out");
		}
	}

	// Returns Webelement from the passed Xpath.
	// Pass the Xpath as parameter.
	WebElement returnElementFromXpath(String xpath) {
		WebElement element = driver.findElement(By.xpath(xpath));
		return element;
	}

	public Pair<Boolean, String> verifyFormLoad() {
		try {
			this.Sleep();
			return Pair.of(addPatientForm.isDisplayed(), "");
		} catch (Exception e) {
			return Pair.of(false, e.toString());
		}
	}
}
