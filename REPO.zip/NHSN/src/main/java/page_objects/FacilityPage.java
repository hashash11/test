package page_objects;

import java.util.ArrayList;

import org.apache.commons.lang3.tuple.Pair;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FacilityPage extends BasePage {

	@FindBy(xpath = "//form")
	private WebElement addPatientForm;

	@FindBy(xpath = "//button/span[text()=\"Next\"]")
	private WebElement nextButton;

	@FindBy(xpath = "//button/span[text()=\"Submit\"]")
	private WebElement submitButton;

	// default values
	public String parent_page_name = "Facility";
	public String facility_info_page_name = "Facility Information";
	public String facitlity_info_navigation_page_name = "Facility Info";
	public String location_page_name = "Locations";
	public String surgeons_page_name = "Surgeons";
	public String customize_forms_page_name = "Customize Forms";

	public FacilityPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	public void fillAddFacilityLocation(String code, String label, String bedSize) {
		try {
			super.fillInputBoxInTableByLabel("Your Code", code);
			super.fillInputBoxInTableByLabel("Your Label", label);
			super.openDropdownAndSelectRandomOptionInDropdown("CDC Description");
			super.openDropdownAndSelectRandomOptionInDropdown("Status");
			super.fillInputBoxInTableByLabel("Bed Size", bedSize);
			super.webElementClick("Submit Button", submitButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddFacilityLocation");
		}
	}

	public void fillAddFacilitySurgeon(String code, String lname, String fmane, String mname) {
		try {
			super.fillInputBoxInTableByLabel("Surgeon  Code", code);
			super.fillInputBoxInTableByLabel("Last Name", lname);
			super.fillInputBoxInTableByLabel("First name", fmane);
			super.fillInputBoxInTableByLabel("Middle name", mname);
			super.openDropdownAndSelectRandomOptionInDropdown("Status");
			super.webElementClick("Submit Button", submitButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddFacilitySurgeon");
		}
	}

	public void fillAddFacilityCustomizeForm(String form_type, String form, String desc, String loc_label) {
		try {
			super.fillInputBoxInTableByLabel("Form Type", form_type);
			super.fillInputBoxInTableByLabel("Form", form);
			super.fillInputBoxInTableByLabel("Description", desc);
			super.fillInputBoxInTableByLabel("Your Loc Label", loc_label);
			super.openDropdownAndSelectRandomOptionInDropdown("Status");
			super.webElementClick("Submit Button", submitButton);
			super.Sleep();
		} catch (Exception e) {
			System.out.println("Error occured fillAddFacilityCustomizeForm");
		}
	}

	public void fillFacilityLocationSearchFields(String search_code, String search_label, String search_cdc_desc,
			String search_cdc_code, String search_nhsn_code, String search_bed_size) {
		try {
			super.fillInputBoxInTableByTableHeader("Your Code", search_code);
			super.fillInputBoxInTableByTableHeader("Your Label", search_label);
			super.fillInputBoxInTableByTableHeader("CDC Description", search_cdc_desc);
			super.fillInputBoxInTableByTableHeader("CDC Code", search_cdc_code);
			super.fillInputBoxInTableByTableHeader("NHSN HL7 Code", search_nhsn_code);
			super.fillInputBoxInTableByTableHeader("Bed Size", search_bed_size);
		} catch (Exception e) {
			System.out.println("Error occured fillFacilityLocationSearchFields");
		}
	}

	// verifies the search result in the table
	public Pair<Boolean,String> verifyFacilityLocationSearchResult(String search_code, String search_label, String search_cdc_desc,
			String search_cdc_code, String search_nhsn_code, String search_bed_size) {
		try {
			ArrayList<Boolean> validation = new ArrayList<Boolean>();
			if (search_code.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Your Code", search_code));
			}
			if (search_label.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Your Label", search_label));
			}
			if (search_cdc_desc.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("CDC Description", search_cdc_desc));
			}
			if (search_cdc_code.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("CDC Code", search_cdc_code));
			}
			if (search_nhsn_code.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("NHSN HL7 Code", search_nhsn_code));
			}
			if (search_bed_size.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Bed Size", search_bed_size));
			}

			Boolean flag = true;
			for (boolean value : validation) {
				if (value == false) {
					flag = false;
					break;
				}
			}
			if (flag == true) {
				return Pair.of(true, "");
			} else {
				return Pair.of(false, "The search result did not match with the provided input.");
			}
		} catch (Exception e) {
			return Pair.of(false, e.toString());
		}
	}

	public void fillFacilitySurgeonsSearchFields(String search_code, String lname, String fname, String mname) {
		try {
			super.fillInputBoxInTableByTableHeader("Surgeon Code", search_code);
			super.fillInputBoxInTableByTableHeader("Last Name", lname);
			super.fillInputBoxInTableByTableHeader("First Name", fname);
			super.fillInputBoxInTableByTableHeader("Middle Name", mname);
		} catch (Exception e) {
			System.out.println("Error occured fillFacilitySurgeonsSearchFields");
		}
	}

	// verifies the search result in the table
	public Pair<Boolean,String> verifyFacilitySurgeonsSearchResult(String search_code, String lname, String fname, String mname) {
		try {
			ArrayList<Boolean> validation = new ArrayList<Boolean>();
			if (search_code.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Surgeon Code", search_code));
			}
			if (lname.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Last Name", lname));
			}
			if (fname.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("First Name", fname));
			}
			if (mname.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Middle Name", mname));
			}

			Boolean flag = true;
			for (boolean value : validation) {
				if (value == false) {
					flag = false;
					break;
				}
			}
			if (flag == true) {
				return Pair.of(true, "");
			} else {
				return Pair.of(false, "The search result did not match with the provided input.");
			}
		} catch (Exception e) {
			return Pair.of(false, e.toString());
		}
	}

	public void fillFacilityCustomizeFormsSearchFields(String form_type, String form, String desc, String location) {
		try {
			super.fillInputBoxInTableByTableHeader("Form Type", form_type);
			super.fillInputBoxInTableByTableHeader("Form", form);
			super.fillInputBoxInTableByTableHeader("Description", desc);
			super.fillInputBoxInTableByTableHeader("Location", location);
		} catch (Exception e) {
			System.out.println("Error occured fillFacilityCustomizeFormsSearchFields");
		}
	}

	// verifies the search result in the table
	public Pair<Boolean,String> verifyFacilityCustomizeFormsSearchResult(String form_type, String form, String desc,
			String location) {
		try {
			ArrayList<Boolean> validation = new ArrayList<Boolean>();
			if (form_type.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Form Type", form_type));
			}
			if (form.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Form", form));
			}
			if (desc.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Description", desc));
			}
			if (location.isEmpty()) {
				validation.add(true);
			} else {
				validation.add(super.verifySearchResultByTableHeader("Location", location));
			}

			Boolean flag = true;
			for (boolean value : validation) {
				if (value == false) {
					flag = false;
					break;
				}
			}
			if (flag == true) {
				return Pair.of(true, "");
			} else {
				return Pair.of(false, "The search result did not match with the provided input.");
			}
		} catch (Exception e) {
			return Pair.of(false, e.toString());
		}
	}
}
