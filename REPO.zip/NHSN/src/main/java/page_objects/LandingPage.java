package page_objects;

import java.io.IOException;

import org.apache.commons.lang3.tuple.Pair;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import manager_objects.ExtentManager;

public class LandingPage extends BasePage {

	@FindBy(xpath = "//*[text()=\"Select Group/Facility \"]/following-sibling::span/input")
	private WebElement openSelectGroupOrFacility;

	@FindBy(xpath = "//*[text()=\"Select facility within the above group:\"]/following-sibling::div//input")
	private WebElement openSelectFacility;

	@FindBy(xpath = "//div[text()=\"Select Component\"]/parent::div//button")
	private WebElement openSelectComponent;

	// default values
	private String component = "Outpatient Procedure";
	private String group = "Romaine's Test OP Group";
	private String direct_facility = "Facility_Young_0001";
	private String facility_under_group = "All Facilities";

	public LandingPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	// Selects component from the landing page (i.e: Outpatient Procedure)
	// Pass the component name as parameter
	public void selectComponent() throws IOException {
		String verification_string = "Select Component";
		try {
			openSelectComponent.click();
			super.Sleep();
			super.clickByXpath(String.format("//ul/li/span[text()=\"%s\"]", component));
			super.Sleep();
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

	public void selectComponent(String component) throws InterruptedException, IOException {
		String verification_string = "Select Component";
		try {
			openSelectComponent.click();
			super.Sleep();
			super.clickByXpath(String.format("//ul/li/span[text()=\"%s\"]", component));
			super.Sleep();
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

	// Selects the facility directly
	// Pass the facily name as parameter
	public void selectFacility() throws InterruptedException, IOException {
		String verification_string = "Select Facility";
		try {
			openSelectGroupOrFacility.click();
			super.Sleep();
			driver.findElement(By.xpath(
					String.format("//td[text()=\"Facility\"]/following-sibling::td[text()=\"%s\"]", direct_facility)))
					.isDisplayed();
			super.clickByXpath(
					String.format("//td[text()=\"Facility\"]/following-sibling::td[text()=\"%s\"]", direct_facility));
			super.Sleep();
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

	public void selectFacility(String facilityName) throws InterruptedException, IOException {
		String verification_string = "Select Facility";
		try {
			openSelectGroupOrFacility.click();
			super.Sleep();
			driver.findElement(By.xpath(
					String.format("//td[text()=\"Facility\"]/following-sibling::td[text()=\"%s\"]", facilityName)))
					.isDisplayed();
			super.clickByXpath(
					String.format("//td[text()=\"Facility\"]/following-sibling::td[text()=\"%s\"]", facilityName));
			super.Sleep();
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

	// Selects the Group first and then the facility available within that group
	// Pass the Group Name & Facility Name within that group as parameter
	public void selectGroupFollowedByFacility() throws InterruptedException, IOException {
		String verification_string = "Select Group Followed By Facility";
		try {
			openSelectGroupOrFacility.click();
			super.Sleep();
			// driver.findElement(By.xpath(String.format("//td[text()=\"Group\"]/following-sibling::td[text()=\"%s\"]",
			// direct_facility))).isDisplayed();
			driver.findElement(
					By.xpath(String.format("//td[text()=\"Group\"]/following-sibling::td[text()=\"%s\"]", group)))
					.isDisplayed();
			super.clickByXpath(String.format("//td[text()=\"Group\"]/following-sibling::td[text()=\"%s\"]", group));
			super.Sleep();
			openSelectFacility.click();
			super.Sleep();
			driver.findElement(By.xpath(String.format("//tr/td[text()=\"%s\"]", facility_under_group))).isDisplayed();
			super.clickByXpath(String.format("//tr/td[text()=\"%s\"]", facility_under_group));
			super.Sleep();
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			try {
				driver.findElement(By.xpath(String.format("//tr/td[text()=\"%s\"]", facility_under_group)))
						.isDisplayed();
				super.clickByXpath(String.format("//tr/td[text()=\"%s\"]", facility_under_group));
				super.Sleep();
				ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
			} catch (Exception ex) {
				ExtentManager.ExecuteTest(verification_string, false, e.toString() + "<br>" + ex.toString(), driver,
						verification_string);
			}
		}
	}

	public void selectGroupFollowedByFacility(String groupName, String facilityName)
			throws InterruptedException, IOException {
		String verification_string = "Select Group Followed By Facility";
		try {
			openSelectGroupOrFacility.click();
			super.Sleep();
			driver.findElement(
					By.xpath(String.format("//td[text()=\"Group\"]/following-sibling::td[text()=\"%s\"]", groupName)))
					.isDisplayed();
			super.clickByXpath(String.format("//td[text()=\"Group\"]/following-sibling::td[text()=\"%s\"]", groupName));
			super.Sleep();
			openSelectFacility.click();
			super.Sleep();
			driver.findElement(By.xpath(String.format("//tr/td[text()=\"%s\"]", facilityName))).isDisplayed();
			super.clickByXpath(String.format("//tr/td[text()=\"%s\"]", facilityName));
			super.Sleep();
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			try {
				driver.findElement(By.xpath(String.format("//tr/td[text()=\"%s\"]", facilityName))).isDisplayed();
				super.clickByXpath(String.format("//tr/td[text()=\"%s\"]", facilityName));
				super.Sleep();
				ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
			} catch (Exception ex) {
				ExtentManager.ExecuteTest(verification_string, false, e.toString() + "<br>" + ex.toString(), driver,
						verification_string);
			}
		}
	}

	// Submits the selection on landing page
	public void submitSelection() throws InterruptedException, IOException {
		String verification_string = "Click <b> Submit</b> button";
		try {
			super.clickByXpath("//*[text()=\"Submit\"]/parent::button");
			super.Sleep();
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

	// Verifies the facility name after selection.
	// Pass the facility name you want to validate as parameter
	public Pair<Boolean, String> verifyFacility(String facilityName) {
		try {
			boolean status = driver.findElement(By.xpath(String.format("//div[text()=\"%s\"]", facilityName)))
					.isDisplayed();
			if (status) {
				return Pair.of(true, "");
			} else {
				return Pair.of(false, "Facility Page was not displayed");
			}
		} catch (Exception e) {
			return Pair.of(false, "Group Page was not displayed<br>" + e.toString());
		}
	}
}
