package page_objects;

import java.io.IOException;

import org.apache.commons.lang3.tuple.Pair;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import manager_objects.ExtentManager;

public class LoginPage extends BasePage {
	@FindBy(xpath = "//legend[contains(text(),\"Login to NHSN\")]")
	private WebElement loginFormTitle;

	@FindBy(xpath = "//h4[contains(text(),\"Conditions of Use and Logon\")]")
	private WebElement conditionsOfUse;

	@FindBy(xpath = "//*[normalize-space(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'))=\"login\"]")
	private WebElement loginButton;

	@FindBy(xpath = "//h2[contains(text(), \"Welcome\")]")
	private WebElement welcomeText;

	@FindBy(xpath = "//label[text()=\"Email\"]/parent::*//input")
	private WebElement userName;

	@FindBy(xpath = "//label[text()=\"Password\"]/parent::*//input")
	private WebElement passWord;

	// default values
	private String user_name = "ryf0@cdc.gov";
	private String pass_word = "Test123$";

	public LoginPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	// Verifies login Page form title and Conditions of Use is being displayed
	// properly in the Login Page.
	// If Visible then returns true.
	public Pair<Boolean, String> verifyLoginPage() {
		try {
			this.Sleep(10);
			boolean form_title_displayed = loginFormTitle.isDisplayed();
			boolean conditions_displayed = conditionsOfUse.isDisplayed();
			if (form_title_displayed && conditions_displayed) {
				return Pair.of(true, "");
			}
			return Pair.of(false, "Login Page was not displayed");
		} catch (Exception e) {
			return Pair.of(false, "Login Page was not displayed<br>" + e.toString());
		}
	}

	// Clicks on login button and waits for page load
	public void login() throws InterruptedException {
		try {
			super.webElementClick("Login Button", loginButton);
			super.Sleep(10);
		} catch (Exception e) {
			System.out.println("Error occured while logging in");
		}
	}

	// Verifies the welcome text that is displayed on Successful login.
	// If welcome text is accurately displayed then returns true.
	public Pair<Boolean, String> verifySuccessfulLogin(String username) {
		try {
			String actual_title = welcomeText.getAttribute("innerHTML").toString();
			if (actual_title.contains(username)) {
				return Pair.of(true, "");
			}
			return Pair.of(false, "Login Unsuccessful");
		} catch (Exception e) {
			return Pair.of(false, "Login Unsuccessful<br>" + e.toString());
		}
	}

	// Populates username and password with the default values provided in this
	// page.
	public void inputUserNameAndPassword() throws IOException {
		String verification_string = "Input <b>Username and Passowrd</b> for Login";
		try {
			userName.clear();
			userName.sendKeys(user_name);
			passWord.clear();
			passWord.sendKeys(pass_word);
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

	// Populates username and password with the values passed as String.
	// Expects Username and Password as parameters.
	public void inputUserNameAndPassword(String username, String password) throws IOException {
		String verification_string = "Input <b>Username and Passowrd</b> for Login";
		try {
			userName.clear();
			userName.sendKeys(username);
			passWord.clear();
			passWord.sendKeys(password);
			ExtentManager.ExecuteTest(verification_string, true, "", driver, verification_string);
		} catch (Exception e) {
			ExtentManager.ExecuteTest(verification_string, false, e.toString(), driver, verification_string);
		}
	}

}
